function [fetal_QRSAnn_est,QT_Interval] = physionet2013(tm,ECG)
% Template algorithm for Physionet/CinC competition 2013. This function can
% be used for events 1 and 2. Participants are free to modify any
% components of the code. However the function prototype must stay the
% same:
%
% [fetal_QRSAnn_est,QT_Interval] = physionet2013(tm,ECG) where the inputs and outputs are specified
% below.
%
% inputs:
%   ECG: 4x60000 (4 channels and 1min of signal at 1000Hz) matrix of
%   abdominal ECG channels.
%   tm : Nx1 vector of time in milliseconds
% output:
%   FQRS: FQRS markers in seconds. Each marker indicates the position of one
%   of the FQRS detected by the algorithm.
%   QT_Interval:   1x1 estimated fetal QT duration (enter NaN or 0 if you do wish to calculate)
%
%
% Author: Joachim Behar - IPMG Oxford (joachim.behar@eng.ox.ac.uk)
% Last updated: March 3, 2013 Ikaro Silva

% ---- check size of ECG ----
if size(ECG,2)>size(ECG,1)
    ECG = ECG';
end

debug = 0;
debug2 = 0;

%% validation of data
AEcg = DetectNan2(tm, ECG);
AEcg = zscore(AEcg);

%% AECG quality assessment and preprocessing
[AEcgAfterPre, AEcgTrend, PrinEcg, FlagA] = AEcgPreprocessWithQualityAssess5(AEcg, debug);

%% MECG R-Wave detection
[MRwaveLocaAll,  MRwaveLocaPca] = MRLoca5(AEcgAfterPre, PrinEcg, FlagA, debug);

%% MECG cancellation
FEcgBeforePre = MEcgCancellation5(AEcgAfterPre, MRwaveLocaAll, FlagA, debug);

%% preprocessing of FECG
FEcgAfterPre = FEcgPreprocess5(FEcgBeforePre, FlagA, debug);

%% finding peaks from FECG
[FRwaveLocaAll, FlagF] = FRLoca5(FEcgAfterPre, FlagA, debug);
fetal_QRSAnn_est = FRwaveLocaAll(:, FlagF);
Much = 0;
if length(fetal_QRSAnn_est)>180
    Much = 1;
end
if std(diff(fetal_QRSAnn_est))<100 && length(fetal_QRSAnn_est)>1.05*length(MRwaveLocaPca) && length(fetal_QRSAnn_est)<180
else
    fetal_QRSAnn_est = [];
%     [AEcgAfterPre, AEcgTrend, PrinEcg, FlagA] = AEcgPreprocessWithQualityAssess6(AEcg, debug);
%     
%     %% MECG R-Wave detection
%     [MRwaveLocaAll,  MRwaveLocaPca] = MRLoca6(AEcgAfterPre, PrinEcg, FlagA, debug);
%     %% MECG cancellation
%      FlagA = [1 1 1 1];
%      FEcgBeforePre = MEcgCancellation5(AEcgAfterPre, MRwaveLocaAll, FlagA, debug);
%     
%     %% preprocessing of FECG
%     FEcgAfterPre = FEcgPreprocess6(FEcgBeforePre, FlagA, debug);
    
    % finding peaks from FECG
    fetal_QRSAnn_est = FRLoca6(FEcgAfterPre,MRwaveLocaPca,FlagA,FlagF,Much,debug2);
end
QT_Interval      = mean(diff(fetal_QRSAnn_est))*0.4;




function AEcg = DetectNan2(xTime, ECG)
%DETECTNAN ECG validation of ECG: if there exist NaN
% 
% $Author: Chengyu Liu and Peng Li 
%           School of Control Science and Engineering,
%           Shandong University
% $Date:    2013.4.22
% 

eg    = ECG;
AEcg  = ECG;
for c = 1:size(eg, 2)
    if any(isnan(eg(:, c))) % existing NaN in this column
        egt = eg(:, c);
        indnan = find(isnan(eg(:, c)));
        indcut = [0; find(diff([indnan; 10e5]) ~= 1)];
        
        % head
        tb = indnan(indcut(1) + 1)-10;
        s1 = tb + 9;
        te = indnan(indcut(1+1))+10;
        if tb  < 1
            tb = 1;
            s1 = indnan(indcut(1) + 1) - 1;
        end
        yinterp = interp1(xTime([tb:s1  te-9:te]), eg([tb:s1 te-9:te], c), xTime(tb:te), 'spline');
        egt(tb:te) = yinterp;
        
        % tail
        tb = indnan(indcut(end-1) + 1)-10;
        te = indnan(indcut(end))+10;
        s2 = te - 9;
        if te  > size(eg, 1)
            te = size(eg, 1);
            s2 = indnan(indcut(end)) + 1;
        end
        yinterp = interp1(xTime([tb:tb+9  s2:te]), eg([tb:tb+9 s2:te], c), xTime(tb:te), 'spline');
        egt(tb:te) = yinterp;
        
        
        for r  = 2:length(indcut)-2
            tb = indnan(indcut(r) + 1)-10;
            te = indnan(indcut(r+1))+10;
            yinterp = interp1(xTime([tb:tb+9  te-9:te]), eg([tb:tb+9 te-9:te], c), xTime(tb:te), 'spline');
            egt(tb:te) = yinterp;
        end
        AEcg(:, c) = egt;
    end
end

function [AEcgAfterPre, AEcgTrend, PrinEcg, Flag] = AEcgPreprocessWithQualityAssess5(AEcgBeforePre, debug)
%AECGPREPROCESSWITHQUALITYASSESS Quality assessment of AECG and preprocess
%       the channel with high quality index, PCA of all channels also exed.
% 
%       an element 2 in the Flag means this channel is superior than the
%       principle component
% 
% $Author: Chengyu Liu and Peng Li 
%           School of Control Science and Engineering,
%           Shandong University
% $Date:    2013.8.18
% 

% +++++++++++++ constants ++++++++++++++++++++++++++++++++++++++++++++++++
[s2read, chan] = size(AEcgBeforePre);

% ============= debug ====================================================
if debug
    figure('Color', 'w', 'Name', 'AECG and trends of different frequencys');
    for k = 1:chan
        eval(['a1' num2str(k) ' = subplot(chan, 1, ' num2str(k) ');']);
        plot(AEcgBeforePre(:, k), 'k');
        hold on
    end
end

% +++++++++++++ preprocessing (hard) +++++++++++++++++++++++++++++++++++++
AEcgHardTre  = zeros(s2read, chan);
for k  = 1:chan
    AEcgBeforePre(:, k) = wden(AEcgBeforePre(:, k), 'rigrsure', 's', 'mln', 3, 'coif5');
    [C, L] = wavedec(AEcgBeforePre(:, k), 6, 'coif5'); % about 8 Hz
    tretp  = upcoef('a', C(1:L(1)), 'coif5', 6);
    indf   = 1 + floor((length(tretp) - s2read)/2) - floor(1*length(wfilters('coif5')));
    AEcgHardTre(:, k) = tretp(indf:indf + s2read - 1);
end
AEcgHardPre = AEcgBeforePre - AEcgHardTre;

% +++++++++++++ quality assessment +++++++++++++++++++++++++++++++++++++++
% 1st step: sample entropy
SampF  = zeros(1, chan);
SampEn = zeros(6, 1);
for k  = 1:chan
    for c = 1:6
        tempSer   = AEcgHardPre((c-1)*1e4+1:(c-1)*1e4+5000, k);
        SampEn(c) = sampen2(zscore(tempSer(10:10:5000)), 2, 0.2);
    end
    SampEn    = sort(SampEn);
    SampF(k)  = mean(SampEn(2:5));
end

% 2nd step: quality assessment (threshold empirically selected at 1.5)
%           at least 2 channels should be returned
Flag = (SampF < 1.5);
if sum(Flag)  < 2
    [kk, ind]  = sort(SampF);
    Flag(ind(1:2)) = 1&1;
end

% ============= debug ====================================================
if debug
    for k = 1:chan
        eval(['plot(AEcgHardTre(:, k), ''g'', ''Parent'', a1' num2str(k) ');']);
    end
    figure('Color', 'w', 'Name', 'Quality assessment');
    for k = 1:chan
        subplot(chan, 1, k)
        plot(AEcgHardPre(:, k), 'k');
        title(['SampEn = ' sprintf('%.2f', SampF(k)) '; Flag = ' num2str(Flag(k))]);
    end
end

% +++++++++++++ PCA ++++++++++++++++++++++++++++++++++++++++++++++++++++++
clear AEcgHardTre C L tretp tempSer; % clear to make room
% moving power noise before pca
Numerator   = [0.730087366780345 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 -0.730087366780345];
Denominator = [1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 -0.46017473356069];
for k = 1:chan
    AEcgHardPre(:, k) = filter(Numerator, Denominator, AEcgHardPre(:, k));
end
[coef, kk] = princomp(AEcgHardPre', 'econ');
PrinEcg   = coef(:, 1);

% +++++++++++++ preprocessing channels with high quality +++++++++++++++++
% clear AEcgHardPre;
AEcgTrend    = zeros(s2read, chan);
AEcgAfterPre = zeros(s2read, chan);
for k = find(Flag)
    [C, L] = wavedec(AEcgBeforePre(:, k), 9, 'coif5'); % about 1 Hz
    tretp  = upcoef('a', C(1:L(1)), 'coif5', 9);
    indf   = 1 + floor((length(tretp) - s2read)/2) - floor(8*length(wfilters('coif5')));
    AEcgTrend(:, k)    = tretp(indf:indf + s2read - 1);
    AEcgAfterPre(:, k) = AEcgBeforePre(:, k) - AEcgTrend(:, k);
end

% +++++++++++++ determine the optimal channel ++++++++++++++++++++++++++++
% principle component
% or the channel with the min SampEn, if the SampEn of principle component
% is too large (larger than 1.5*min)
for c = 1:6
    tempSer   = PrinEcg((c-1)*1e4+1:(c-1)*1e4+5000);
    SampEn(c) = sampen2(zscore(tempSer(10:10:5000)), 2, 0.2);
end
SampEn = sort(SampEn);
if mean(SampEn(2:5)) >= 1.5*min(SampF) && mean(SampEn(2:5)) > 1
    [kk, ind]  = min(SampF);
    PrinEcg   = AEcgHardPre(:, ind);
    Flag      = double(Flag);
    Flag(ind) = 2;
end

% ============= debug ====================================================
if debug
    for k = 1:chan
        eval(['plot(AEcgTrend(:, k), ''r'', ''Parent'', a1' num2str(k) ');']);
    end
end

function [AEcgAfterPre, AEcgTrend, PrinEcg, Flag] = AEcgPreprocessWithQualityAssess6(AEcgBeforePre, debug)
%AECGPREPROCESSWITHQUALITYASSESS Quality assessment of AECG and preprocess
%       the channel with high quality index, PCA of all channels also exed.
% 
%       an element 2 in the Flag means this channel is superior than the
%       principle component
% 
% $Author: Chengyu Liu and Peng Li 
%           School of Control Science and Engineering,
%           Shandong University
% $Date:    2013.8.18
% 

% +++++++++++++ constants ++++++++++++++++++++++++++++++++++++++++++++++++
[s2read, chan] = size(AEcgBeforePre);

% ============= debug ====================================================
if debug
    figure('Color', 'w', 'Name', 'AECG and trends of different frequencys');
    for k = 1:chan
        eval(['a1' num2str(k) ' = subplot(chan, 1, ' num2str(k) ');']);
        plot(AEcgBeforePre(:, k), 'k');
        hold on
    end
end

% +++++++++++++ preprocessing (hard) +++++++++++++++++++++++++++++++++++++
AEcgHardTre  = zeros(s2read, chan);
for k  = 1:chan
    AEcgBeforePre(:, k) = wden(AEcgBeforePre(:, k), 'rigrsure', 's', 'mln', 3, 'coif5');
    [C, L] = wavedec(AEcgBeforePre(:, k), 6, 'coif5'); % about 8 Hz
    tretp  = upcoef('a', C(1:L(1)), 'coif5', 6);
    indf   = 1 + floor((length(tretp) - s2read)/2) - floor(1*length(wfilters('coif5')));
    AEcgHardTre(:, k) = tretp(indf:indf + s2read - 1);
end
AEcgHardPre = AEcgBeforePre - AEcgHardTre;

% +++++++++++++ quality assessment +++++++++++++++++++++++++++++++++++++++
% 1st step: sample entropy
SampF  = zeros(1, chan);
SampEn = zeros(6, 1);
for k  = 1:chan
    for c = 1:6
        tempSer   = AEcgHardPre((c-1)*1e4+1:(c-1)*1e4+5000, k);
        SampEn(c) = sampen2(zscore(tempSer(10:10:5000)), 2, 0.2);
    end
    SampEn    = sort(SampEn);
    SampF(k)  = mean(SampEn(2:5));
end

% 2nd step: quality assessment (threshold empirically selected at 1.5)
%           at least 2 channels should be returned
Flag = (SampF < 1.5);
if sum(Flag)  < 2
    [kk, ind]  = sort(SampF);
    Flag(ind(1:2)) = 1&1;
end

% ============= debug ====================================================
if debug
    for k = 1:chan
        eval(['plot(AEcgHardTre(:, k), ''g'', ''Parent'', a1' num2str(k) ');']);
    end
    figure('Color', 'w', 'Name', 'Quality assessment');
    for k = 1:chan
        subplot(chan, 1, k)
        plot(AEcgHardPre(:, k), 'k');
        title(['SampEn = ' sprintf('%.2f', SampF(k)) '; Flag = ' num2str(Flag(k))]);
    end
end

% +++++++++++++ PCA ++++++++++++++++++++++++++++++++++++++++++++++++++++++
clear AEcgHardTre C L tretp tempSer; % clear to make room
% moving power noise before pca
Numerator   = [0.730087366780345 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 -0.730087366780345];
Denominator = [1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 -0.46017473356069];
for k = 1:chan
    AEcgHardPre(:, k) = filter(Numerator, Denominator, AEcgHardPre(:, k));
end
[coef, kk] = princomp(AEcgHardPre', 'econ');
PrinEcg   = coef(:, 1);

% +++++++++++++ preprocessing channels with high quality +++++++++++++++++
% clear AEcgHardPre;
AEcgTrend    = zeros(s2read, chan);
AEcgAfterPre = zeros(s2read, chan);
for k = 1:4
    [C, L] = wavedec(AEcgBeforePre(:, k), 9, 'coif5'); % about 1 Hz
    tretp  = upcoef('a', C(1:L(1)), 'coif5', 9);
    indf   = 1 + floor((length(tretp) - s2read)/2) - floor(8*length(wfilters('coif5')));
    AEcgTrend(:, k)    = tretp(indf:indf + s2read - 1);
    AEcgAfterPre(:, k) = AEcgBeforePre(:, k) - AEcgTrend(:, k);
end

% +++++++++++++ determine the optimal channel ++++++++++++++++++++++++++++
% principle component
% or the channel with the min SampEn, if the SampEn of principle component
% is too large (larger than 1.5*min)
for c = 1:6
    tempSer   = PrinEcg((c-1)*1e4+1:(c-1)*1e4+5000);
    SampEn(c) = sampen2(zscore(tempSer(10:10:5000)), 2, 0.2);
end
SampEn = sort(SampEn);
if mean(SampEn(2:5)) >= 1.5*min(SampF) && mean(SampEn(2:5)) > 1
    [kk, ind]  = min(SampF);
    PrinEcg   = AEcgHardPre(:, ind);
    Flag      = double(Flag);
    Flag(ind) = 2;
end

% ============= debug ====================================================
if debug
    for k = 1:chan
        eval(['plot(AEcgTrend(:, k), ''r'', ''Parent'', a1' num2str(k) ');']);
    end
end

function [MRwaveLocaAll, MRwaveLocaPca] = MRLoca5(AEcgAfterPre, PrinEcg, Flag, debug)
%MRLOCA R-Wave detection (MECG)
%           by PCA,
%           or by the orignal channel with the min SampEn if PCA has too
%           large SampEn
% $Author: Chengyu Liu and Peng Li 
%           School of Control Science and Engineering,
%           Shandong University
% $Date:    2013.8.18
% 

% +++++++++++++ constants ++++++++++++++++++++++++++++++++++++++++++++++++
[s2read, chan] = size(AEcgAfterPre);

% +++++++++++++ find peaks from the PrinEcg ++++++++++++++++++++++++++++++
MRwaveLocaPca = MPeak5(PrinEcg);

% +++++++++++++ locate the main wave +++++++++++++++++++++++++++++++++++++
% 1st step: determine the direction of the main wave
MPolar = zeros(1, chan);
Mareai = repmat(MRwaveLocaPca(2:end-1), 1, 200) + repmat(-99:100, length(MRwaveLocaPca)-2, 1);
for k  = find(Flag)
    temp  = AEcgAfterPre(:, k);
    Marea = temp(Mareai);
    H     = max(Marea, [], 2)  - mean(Marea, 2);
    L     = mean(Marea, 2) - min(Marea, [], 2);
    MPolar(k) = sign(sum(sign(H - L)));
end

% 2nd step: determine the real location
MRwaveLocaAll = zeros(length(MRwaveLocaPca), chan);
for k = find(Flag)
    peaktemp  = zeros(size(MRwaveLocaPca));
    switch MPolar(k)
        case -1
            fun = 'min';
        otherwise
            fun = 'max';
    end
    for p = 1:length(MRwaveLocaPca)
        indsta = max([1      MRwaveLocaPca(p)-30]);
        indend = min([s2read MRwaveLocaPca(p)+30]);
        [kk, indM]   = feval(fun, AEcgAfterPre(indsta:indend, k));
        peaktemp(p) = indM + indsta - 1;
    end
    MRwaveLocaAll(:, k) = peaktemp(:);
end

% 3rd step: validate head and tail
% ********  features
FlagF    = find(Flag);
peakt    = MRwaveLocaAll(:, FlagF(1));
x        = AEcgAfterPre(:, FlagF(1));
switch MPolar(FlagF(1))
        case -1
            fun = 'min';
        otherwise
            fun = 'max';
end
tempind  = repmat(peakt(2:end-1), 1, 100) + repmat([-50:49], length(peakt(2:end-1)), 1);
ampind   = feval(fun, x(tempind), [], 2);
amp      = sort(abs(ampind));
if length(amp) > 15
    meanamp   = mean(amp(5:15));
else
    meanamp   = mean(amp);
end
meanp  = mean([max(abs(x(1000:3000))) max(abs(x(5000:7000))) max(abs(x(9000:11000))) max(abs(x(13000:15000)))]);
HR     = mean(diff(peakt));
markht = 0;
N      = s2read;
% ********  head
if peakt(1) > 1.55*HR % must missing one beat at the head
    staind = peakt(1) - floor(1.3*HR);
    [kk, maxind] = feval(fun, x(staind:staind+floor(0.6*HR)));
    peakt  = [maxind+staind-1; peakt];
    markht = 1;
elseif peakt(1) > 1.15*HR % possibly missing one beat at the head
    sta = 1;
    if max(abs(x(1:50))) > 2*meanp
        sta = 80;
    end
    [mmax, maxind] = feval(fun, x(sta:floor(0.5*HR)));
    if abs(mmax)   > 0.6*meanamp
        peakt      = [maxind+sta-1; peakt];
        markht = 1;
    end
end
% ********  tail
if N - peakt(end) > 1.55*HR % must missing one beat at the tail
    staind = peakt(end) + floor(0.7*HR);
    endind = min([N staind+floor(0.6*HR)]);
    [kk, maxind] = feval(fun, x(staind:endind));
    peakt  = [peakt; maxind + staind - 1];
    markht = 2;
elseif N - peakt(end) > 1.15*HR % possibly missing one beat at the tail
    fin = N;
    if max(abs(x(end-49:end))) > 2*meanp
        fin = N-79;
    end
    [mmax, maxind] = feval(fun, x(end-floor(0.5*HR):fin));
    if abs(mmax)   > 0.6*meanamp
        peakt      = [peakt; maxind + N - floor(0.5*HR) - 1];
        markht = 2;
    end
end

switch markht
    case 1
        MRwaveLocaAllo = MRwaveLocaAll;
        MRwaveLocaAll  = zeros(length(peakt), chan);
        for k = find(Flag)
            switch MPolar(k)
                case -1
                    fun = 'min';
                otherwise
                    fun = 'max';
            end
            indsta = max([1 peakt(1)-30]);
            indend = peakt(1)+30;
            [kk, indM] = feval(fun, AEcgAfterPre(indsta:indend, k));
            peaktemp  = indM + indsta - 1;
            MRwaveLocaAll(:, k) = [peaktemp; MRwaveLocaAllo(:, k)];
        end
    case 2
        MRwaveLocaAllo = MRwaveLocaAll;
        MRwaveLocaAll  = zeros(length(peakt), chan);
        for k = find(Flag)
            switch MPolar(k)
                case -1
                    fun = 'min';
                otherwise
                    fun = 'max';
            end
            indsta = peakt(end)-30;
            indend = max([s2read peakt(end)+30]);
            [kk, indM] = feval(fun, AEcgAfterPre(indsta:indend, k));
            peaktemp  = indM + indsta - 1;
            MRwaveLocaAll(:, k) = [MRwaveLocaAllo(:, k); peaktemp];
        end
end

% ============= debug ====================================================
if debug
    figure('Color', 'w', 'Name', 'PrinEcg and its peaks');
    plot(PrinEcg, 'k');
    hold on
    plot(MRwaveLocaPca, PrinEcg(MRwaveLocaPca), 'ro');
    
    figure('Color', 'w', 'Name', 'R wave in all channels with high quality');
    for k = 1:chan
        subplot(chan, 1, k)
        plot(AEcgAfterPre(:, k), 'k');
        hold on
        if Flag(k)
            plot(MRwaveLocaAll(:, k), AEcgAfterPre(MRwaveLocaAll(:, k), k), 'ro');
        end
        title(['Flag = ' num2str(Flag(k))]);
    end
end

function [MRwaveLocaAll, MRwaveLocaPca] = MRLoca6(AEcgAfterPre, PrinEcg, Flag, debug)
%MRLOCA R-Wave detection (MECG)
%           by PCA,
%           or by the orignal channel with the min SampEn if PCA has too
%           large SampEn
% $Author: Chengyu Liu and Peng Li 
%           School of Control Science and Engineering,
%           Shandong University
% $Date:    2013.8.18
% 

% +++++++++++++ constants ++++++++++++++++++++++++++++++++++++++++++++++++
[s2read, chan] = size(AEcgAfterPre);

% +++++++++++++ find peaks from the PrinEcg ++++++++++++++++++++++++++++++
MRwaveLocaPca = MPeak5(PrinEcg);
Flag = [1 1 1 1];
% +++++++++++++ locate the main wave +++++++++++++++++++++++++++++++++++++
% 1st step: determine the direction of the main wave
MPolar = zeros(1, chan);
Mareai = repmat(MRwaveLocaPca(2:end-1), 1, 200) + repmat(-99:100, length(MRwaveLocaPca)-2, 1);
for k  = 1:4
    temp  = AEcgAfterPre(:, k);
    Marea = temp(Mareai);
    H     = max(Marea, [], 2)  - mean(Marea, 2);
    L     = mean(Marea, 2) - min(Marea, [], 2);
    MPolar(k) = sign(sum(sign(H - L)));
end

% 2nd step: determine the real location
MRwaveLocaAll = zeros(length(MRwaveLocaPca), chan);
for k = 1:4
    peaktemp  = zeros(size(MRwaveLocaPca));
    switch MPolar(k)
        case -1
            fun = 'min';
        otherwise
            fun = 'max';
    end
    for p = 1:length(MRwaveLocaPca)
        indsta = max([1      MRwaveLocaPca(p)-30]);
        indend = min([s2read MRwaveLocaPca(p)+30]);
        [kk, indM]   = feval(fun, AEcgAfterPre(indsta:indend, k));
        peaktemp(p) = indM + indsta - 1;
    end
    MRwaveLocaAll(:, k) = peaktemp(:);
end

% 3rd step: validate head and tail
% ********  features
FlagF    = find(Flag);
peakt    = MRwaveLocaAll(:, FlagF(1));
x        = AEcgAfterPre(:, FlagF(1));
switch MPolar(FlagF(1))
        case -1
            fun = 'min';
        otherwise
            fun = 'max';
end
tempind  = repmat(peakt(2:end-1), 1, 100) + repmat([-50:49], length(peakt(2:end-1)), 1);
ampind   = feval(fun, x(tempind), [], 2);
amp      = sort(abs(ampind));
if length(amp) > 15
    meanamp   = mean(amp(5:15));
else
    meanamp   = mean(amp);
end
meanp  = mean([max(abs(x(1000:3000))) max(abs(x(5000:7000))) max(abs(x(9000:11000))) max(abs(x(13000:15000)))]);
HR     = mean(diff(peakt));
markht = 0;
N      = s2read;
% ********  head
if peakt(1) > 1.55*HR % must missing one beat at the head
    staind = peakt(1) - floor(1.3*HR);
    [kk, maxind] = feval(fun, x(staind:staind+floor(0.6*HR)));
    peakt  = [maxind+staind-1; peakt];
    markht = 1;
elseif peakt(1) > 1.15*HR % possibly missing one beat at the head
    sta = 1;
    if max(abs(x(1:50))) > 2*meanp
        sta = 80;
    end
    [mmax, maxind] = feval(fun, x(sta:floor(0.5*HR)));
    if abs(mmax)   > 0.6*meanamp
        peakt      = [maxind+sta-1; peakt];
        markht = 1;
    end
end
% ********  tail
if N - peakt(end) > 1.55*HR % must missing one beat at the tail
    staind = peakt(end) + floor(0.7*HR);
    endind = min([N staind+floor(0.6*HR)]);
    [kk, maxind] = feval(fun, x(staind:endind));
    peakt  = [peakt; maxind + staind - 1];
    markht = 2;
elseif N - peakt(end) > 1.15*HR % possibly missing one beat at the tail
    fin = N;
    if max(abs(x(end-49:end))) > 2*meanp
        fin = N-79;
    end
    [mmax, maxind] = feval(fun, x(end-floor(0.5*HR):fin));
    if abs(mmax)   > 0.6*meanamp
        peakt      = [peakt; maxind + N - floor(0.5*HR) - 1];
        markht = 2;
    end
end

switch markht
    case 1
        MRwaveLocaAllo = MRwaveLocaAll;
        MRwaveLocaAll  = zeros(length(peakt), chan);
        for k = find(Flag)
            switch MPolar(k)
                case -1
                    fun = 'min';
                otherwise
                    fun = 'max';
            end
            indsta = max([1 peakt(1)-30]);
            indend = peakt(1)+30;
            [kk, indM] = feval(fun, AEcgAfterPre(indsta:indend, k));
            peaktemp  = indM + indsta - 1;
            MRwaveLocaAll(:, k) = [peaktemp; MRwaveLocaAllo(:, k)];
        end
    case 2
        MRwaveLocaAllo = MRwaveLocaAll;
        MRwaveLocaAll  = zeros(length(peakt), chan);
        for k = find(Flag)
            switch MPolar(k)
                case -1
                    fun = 'min';
                otherwise
                    fun = 'max';
            end
            indsta = peakt(end)-30;
            indend = max([s2read peakt(end)+30]);
            [kk, indM] = feval(fun, AEcgAfterPre(indsta:indend, k));
            peaktemp  = indM + indsta - 1;
            MRwaveLocaAll(:, k) = [MRwaveLocaAllo(:, k); peaktemp];
        end
end

% ============= debug ====================================================
if debug
    figure('Color', 'w', 'Name', 'PrinEcg and its peaks');
    plot(PrinEcg, 'k');
    hold on
    plot(MRwaveLocaPca, PrinEcg(MRwaveLocaPca), 'ro');
    
    figure('Color', 'w', 'Name', 'R wave in all channels with high quality');
    for k = 1:chan
        subplot(chan, 1, k)
        plot(AEcgAfterPre(:, k), 'k');
        hold on
        if Flag(k)
            plot(MRwaveLocaAll(:, k), AEcgAfterPre(MRwaveLocaAll(:, k), k), 'ro');
        end
        title(['Flag = ' num2str(Flag(k))]);
    end
end



function PeakLoca = MPeak5(x)
%MPEAK          Finding peaks
%               only for MECG
%
% $Author: Chengyu Liu and Peng Li 
%           School of Control Science and Engineering,
%           Shandong University
% $Date:    2013.8.19

% +++++++++++++ constants ++++++++++++++++++++++++++++++++++++++++++++++++
fs = 1000;
N  = length(x);
fratio  = fs/250;                               % Frequence ratio w.r.t. 250hz.360hz;
hwin    = ceil(5*fratio);                       % half window width for parabolic fitting ==20
weights = 1:(-1/hwin):(1/hwin);                 % parabolic fitting weights in half window ==[20*1]
dsw     = sqrt([fliplr(weights), 1, weights])'; % square root of double side weights == [41*1]
xw      = [-((-hwin:hwin).^2)', ones(2*hwin+1, 1)];
xw      = dsw(:, [1 1]) .* xw; % [41*2]
invxw   = inv(xw'*xw)*xw';     % [2*41]

% +++++++++++++ strengthen QRS by parabolic fitting and then log +++++++++
xo    = x;
meanp = mean([max(abs(x(1000:3000))) max(abs(x(5000:7000))) max(abs(x(9000:11000))) max(abs(x(13000:15000)))]);
if max(abs(x(1:50))) > 2*meanp
    x(1:100) = 0;
elseif max(abs(x(end-49:end))) > 2*meanp
    x(end-99:end) = 0;
end
x1 = [x(50:-1:1); x; x(end-49:end)];
N1 = length(x1);
ps2     = zeros(N1, 1);
ps0     = zeros(N1, 1);
for k = (hwin+1):(N1-hwin)
    yw = x1((k-hwin):(k+hwin));
    yw = dsw .* yw;
    th = invxw*yw;
    ps2(k) = th(1);
    ps0(k) = th(2);
end
steF = ps2.*ps0;
steF = steF(51:end-50);
indm    = hankel(1:length(x), length(x):length(x)+99);
envTemp = [steF(50:-1:1); steF; steF(end-49:end)];
envSteF = -1./100.*sum(abs(envTemp(indm)).^3.*log(abs(envTemp(indm)).^3), 2);
envSteF(isnan(envSteF)) = 0;

% +++++++++++++ find peaks in the envelop ++++++++++++++++++++++++++++++++
% 1st step: threshold
sL     = floor(N/10);
envEpi = reshape(envSteF(1:sL*10), sL, 10);
envEpi = sort(envEpi);
threT  = mean(envEpi(end-floor(0.1*sL):end-floor(0.08*sL), :)).*0.3; % 0.3 important!
thre   = min(threT);

% 2nd step: thresholding process
temp = envSteF;
temp(temp <  thre) = 0;
temp(temp >= thre) = 1;

% 3rd step: find peaks
staind = find(diff(temp) == 1) + 1;
endind = find(diff(temp) == -1);

if endind(1) < staind(1)
    staind = [1; staind];
end
if staind(end) > endind(end)
    endind = [endind; N];
end

peakt = [];
for k = 1:length(staind)
    tempSteF = steF(staind(k):endind(k));
    [kk, maxInd] = max(tempSteF);
    peakt = [peakt; maxInd + staind(k) - 1];
end

% +++++++++++++ FP and FN ++++++++++++++++++++++++++++++++++++++++++++++++
% 0th step: direction
x      = xo;
Mareai = repmat(peakt(2:end-1), 1, 200) + repmat(-99:100, length(peakt)-2, 1);
Marea  = x(Mareai);
H      = max(Marea, [], 2)  - mean(Marea, 2);
L      = mean(Marea, 2)     - min(Marea, [], 2);
switch sign(sum(sign(H - L)))
    case -1
        fun = 'min';
    otherwise
        fun = 'max';
end
for p = 1:length(peakt)
    indsta = max([1 peakt(p)-30]);
    indend = min([N peakt(p)+30]);
    [kk, indM] = feval(fun, x(indsta:indend));
    peakt(p)  = indM + indsta - 1;
end

% 1st step: possibly missing beats in the head and tail
% ********  features
tempind  = repmat(peakt(2:end-1), 1, 100) + repmat([-50:49], length(peakt(2:end-1)), 1);
ampind   = feval(fun, x(tempind), [], 2);
amp      = sort(abs(ampind));
if length(amp) > 15
    meanamp   = mean(amp(5:15));
else
    meanamp   = mean(amp);
end
HR       = mean(diff(peakt));
% ********  head
if peakt(1) > 1.55*HR % must missing one beat at the head
    staind = peakt(1) - floor(1.3*HR);
    [kk, maxind] = feval(fun, x(staind:staind+floor(0.6*HR)));
    peakt = [maxind+staind-1; peakt];
elseif peakt(1) > 1.15*HR % possibly missing one beat at the head
    sta = 1;
    if max(abs(x(1:50))) > 2*meanp
        sta = 80;
    end
    [mmax, maxind] = feval(fun, x(sta:floor(0.5*HR)));
    if abs(mmax)   > 0.6*meanamp
        peakt      = [maxind+sta-1; peakt];
    end
elseif peakt(1) > 0.75*HR % possibly missing one beat at the head
    sta = 1;
    if max(abs(x(1:50))) > 2*meanp
        sta = 80;
    end
    [mmax, maxind] = feval('max', x(sta:floor(0.3*HR)));
    [mmin, minind] = feval('min', x(sta:floor(0.3*HR)));
    if abs(mmax) <= abs(mmin)
        mmax   = mmin;
        maxind = minind;
    end
    if abs(mmax) > 0.6*meanamp
        peakt    = [maxind+sta-1; peakt];
    end
end
% ********  tail
if N - peakt(end) > 1.55*HR % must missing one beat at the tail
    staind = peakt(end) + floor(0.7*HR);
    endind = min([N staind+floor(0.6*HR)]);
    [kk, maxind] = feval(fun, x(staind:endind));
    peakt = [peakt; maxind + staind - 1];
elseif N - peakt(end) > 1.15*HR % possibly missing one beat at the tail
    fin = N;
    if max(abs(x(end-49:end))) > 2*meanp
        fin = N-79;
    end
    [mmax, maxind] = feval(fun, x(end-floor(0.5*HR):fin));
    if abs(mmax)   > 0.6*meanamp
        peakt      = [peakt; maxind + N - floor(0.5*HR) - 1];
    end
elseif N - peakt(end) > 0.75*HR % possibly missing one beat at the tail
    fin = N;
    if max(abs(x(end-49:end))) > 2*meanp
        fin = N-79;
    end
    [mmax, maxind] = feval('max', x(end-floor(0.3*HR):fin));
    [mmin, minind] = feval('min', x(end-floor(0.3*HR):fin));
    if abs(mmax) <= abs(mmin)
        mmax   = mmin;
        maxind = minind;
    end
    if abs(mmax) > 0.6*meanamp
        peakt    = [peakt; maxind + N - floor(0.3*HR) - 1];
    end
end

% 2nd step: false positive
meanHR  = mean(diff(peakt));
if meanHR  < 450
    meanHR = 550;
elseif meanHR > 1400
    meanHR    = 650;
end
peak1 = peakt(diff([peakt; 10e6]) > 0.55*meanHR);

% 3rd step: false negative
amp   = sort(abs(steF(peak1)));
if length(amp) > 10
    meanamp = mean(amp(1:10));
else
    meanamp = mean(abs(steF(peak1)));
end
peak1 = [1; peak1; N];
newpeak = [];
errBeat = [];
indn    = find(diff(peak1) > 1.55*meanHR); % position of possibly missing beats
if isempty(indn)
    PeakLoca = unique(peak1(2:end-1));
else
    k = 1;
    endRev = [];
    while 1
        staRev = peak1(indn(k));
        for iCnt = 1:length(indn) - 1
            endInd = indn(k) + iCnt;
            if k+iCnt > length(indn)
                endRev = peak1(endInd);
                break;
            elseif endInd == indn(k+iCnt);
                errBeat = [errBeat; peak1(endInd)];
            else
                endRev  = peak1(endInd);
                break;
            end
        end
        if isempty(endRev)
            endRev = peak1(indn(end) + 1);
        end
        
        MissNum = ceil(length(staRev:endRev) / meanHR); % number of possibly missing beats
        
        Epi = steF(staRev:endRev);
        epi = floor(length(Epi) / 10);
        Mpi = reshape(Epi(1:epi*10), epi, 10);
        mpi = sort(max(Mpi));
        if abs(mean(mpi(3:end-2))) > 0.9*meanamp
            thre = 0.75;
        elseif abs(mean(mpi(3:end-2))) > 0.7*meanamp
            thre = 0.55;
        elseif abs(mean(mpi(3:end-2))) > 0.5*meanamp
            thre = 0.35;
        elseif abs(mean(mpi(3:end-2))) > 0.3*meanamp
            thre = 0.3;
        else
            thre = 0.2;
        end
        
        for mn = 1:MissNum
            for jCnt = 1:6
                fid  = min([floor(peak1(indn(k)) + (mn+jCnt*0.05)*meanHR) N]);
                if fid < endRev
                    tRR = steF(fid - floor(0.1*jCnt*meanHR):fid);
                    [maxt, maxind] = max(tRR);
                    if abs(maxt) > thre*meanamp
                        newpeak = [newpeak; maxind + fid - floor(0.1*jCnt*meanHR)];
                        break;
                    end
                else
                    if ~isempty(newpeak)
                        if endRev - newpeak(end) < 0.55*meanHR % error beat
                            errBeat = [errBeat; endRev];
                            tRR = steF(fid - floor(0.1*jCnt*meanHR):fid);
                            [maxt, maxind] = max(tRR);
                            if abs(maxt) > 0.6*meanamp
                                newpeak = [newpeak; maxind + fid - floor(0.1*jCnt*meanHR)];
                                break;
                            end
                        end
                    end
                end
            end
        end
        
        if endRev == peak1(indn(end) + 1)
            break;
        end
        
        k = k + iCnt;
        if k > length(indn)
            break;
        end
    end
    
    peak2 = sort([peak1; newpeak]);
    peak2([1 end]) = [];
    if ~isempty(errBeat)
        [kk, IA, kk] = intersect(peak2, errBeat);
        peak2(IA) = [];
    end
    peak2    = unique(peak2);
    PeakLoca = peak2;
end

% +++++++++++++ TN +++++++++++++++++++++++++++++++++++++++++++++++++++++++
RR   = diff(PeakLoca);
HR   = mean(RR);
sRra = RR(1:end-1)./RR(2:end);
indn = (sRra >= 1.35);
if any(indn)
    indtn = find(indn);
    for k = 1:length(indtn)
        if indtn(k) ~= 1 && ((PeakLoca(indtn(k)) - PeakLoca(indtn(k)-1))/HR <= 1.3 || (PeakLoca(indtn(k)) - PeakLoca(indtn(k)-1))/HR >= 0.7)
            [kk, tp] = feval(fun, x(PeakLoca(indtn(k)) + round(0.8*HR):PeakLoca(indtn(k)) + round(1.2*HR)));
            PeakLoca(indtn(k)+1) = tp + PeakLoca(indtn(k)) + round(0.8*HR) - 1;
        else
            [kk, tp] = feval(fun, x(PeakLoca(indtn(k)+1) - round(1.2*HR):PeakLoca(indtn(k)+1) - round(0.8*HR)));
            PeakLoca(indtn(k)) = tp + PeakLoca(indtn(k)+1) - round(1.2*HR) - 1;
        end
    end
end

% validate head and tail
if (PeakLoca(3)-PeakLoca(2))/(PeakLoca(2)-PeakLoca(1)) > 1.3
    sta = max([1 PeakLoca(2)-round(1.15*mean(diff(PeakLoca)))]);
    if PeakLoca(2)-round(0.85*mean(diff(PeakLoca))) > 1
        [mm, ind] = feval(fun, x(sta:PeakLoca(2)-round(0.85*mean(diff(PeakLoca)))));
        if abs(mm) > 0.8*mean(x(PeakLoca))
            PeakLoca(1) = ind + sta - 1;
        end
    end
end
if (PeakLoca(end-2)-PeakLoca(end-1))/(PeakLoca(end-1)-PeakLoca(end)) > 1.3
    fin = min([N PeakLoca(end-1)+round(1.15*mean(diff(PeakLoca)))]);
    if PeakLoca(end-1)+round(0.85*mean(diff(PeakLoca))) < N
        [mm, ind] = feval(fun, x(PeakLoca(end-1)+round(0.85*mean(diff(PeakLoca))):fin));
        if abs(mm) > 0.8*mean(x(PeakLoca))
            PeakLoca(end) = ind + PeakLoca(end-1)+round(0.85*mean(diff(PeakLoca))) - 1;
        end
    end
end

function FEcg = MEcgCancellation5(AEcgAfterPre, MRwaveLocaAll, Flag, debug)
%MECGCANCELLATION Reconstruct MECG signal based on template compressing
%                       or stretching
%                 and cancellate them from the preprocessed AECG
% Only the channel with Flag == 1 is processed
% 
% $Author: Chengyu Liu and Peng Li 
%           School of Control Science and Engineering,
%           Shandong University
% $Date:    2013.8.22
% 

% +++++++++++++ constants ++++++++++++++++++++++++++++++++++++++++++++++++
[s2read, chan] = size(AEcgAfterPre);
NumOfPeriod    = size(MRwaveLocaAll, 1);

% +++++++++++++ templates ++++++++++++++++++++++++++++++++++++++++++++++++
% 1st step: template stretching and compressing
MEcgb = zeros(s2read, chan);
for c = find(Flag)
    peakt = MRwaveLocaAll(:, c);
    temp  = AEcgAfterPre(:, c);

    % strange intervals
    RRint = sort(diff(peakt));
    thre  = floor(length(RRint)*0.1);
    LowTh = RRint(thre);
    HigTh = RRint(length(RRint) - thre);
    
    % strange amplitude
    Ramp  = sort(abs(temp(peakt)));
    thre2 = floor(length(Ramp)/6);
    LowAh = Ramp(thre2);
    HigAh = Ramp(length(Ramp) - thre2);
    
    % averaging
    tempL = max(diff(peakt));
    allRR = [];
    for k = 1:length(peakt)-1
        tempInt = peakt(k+1) - peakt(k);
        if tempInt >= LowTh && tempInt <= HigTh ...
                && abs(temp(peakt(k))) >= LowAh && abs(temp(peakt(k))) <= HigAh ...
                && abs(temp(peakt(k+1))) >= LowAh && abs(temp(peakt(k+1))) <= HigAh
            tempRR = temp(peakt(k):peakt(k+1));
            
            % stretching
            inds = linspace(0, length(tempRR)-1, tempL);
            sRR  = interp1(0:length(tempRR)-1, tempRR, inds);
            
            allRR = [allRR sRR(:)];
        end
    end
    
    RRtemp = mean(allRR, 2);
    
    % reconstructing
    tempM = [];
    for k = 1:length(peakt)-1
        % compressing
        inds = linspace(0, tempL-1, peakt(k+1)-peakt(k) + 1);
        cRR  = interp1(0:tempL-1, RRtemp, inds);
        cRR  = cRR(:);
        tempM = [tempM; cRR(1:end-1)];
    end
    
    % head and tail
    tailRR = [RRtemp; RRtemp];
    tempM  = [tailRR(end-peakt(1)+2:end); tempM; tailRR(1:s2read-peakt(end)+1)];
    MEcgb(:, c) = tempM(:);
end

% 2nd step: slight adjustment of template in each period
MEcg     = MEcgb;
staOfAdj = 1;
endOfAdj = NumOfPeriod;
pMove    = 5;
meanHR   = ceil(mean(RRint(round(0.1*NumOfPeriod):end-floor(0.1*NumOfPeriod))));
HWnd     = round(.08*meanHR);
p1Loca   = MRwaveLocaAll(1,   Flag == 1);
pnLoca   = MRwaveLocaAll(end, Flag == 1);
if min(p1Loca) <= HWnd + 2*pMove
    staOfAdj    = 2;
end
if max(pnLoca) >= s2read - HWnd - 2*pMove - 1
    endOfAdj    = NumOfPeriod - 1;
end

ct    = zeros(2*pMove + 1, 1);
ct2   = ct;
for c = find(Flag)
    for p  = staOfAdj:endOfAdj
        for pt = -pMove:pMove
            xy = corrcoef(MEcg(MRwaveLocaAll(p, c)-HWnd+pt:MRwaveLocaAll(p, c)+HWnd+pt, c), ...
                AEcgAfterPre(MRwaveLocaAll(p, c)-HWnd:MRwaveLocaAll(p, c)+HWnd, c));
            ct(pt+pMove+1) = xy(2);
        end
        
        [kk, ctMaxInd] = max(ct);
        X  = MEcg(MRwaveLocaAll(p, c)-HWnd+ctMaxInd-pMove-1-pMove:MRwaveLocaAll(p, c)+HWnd+ctMaxInd-pMove-1+pMove, c);
        X1 = [];
        for pt = -0.5:0.1:0.5
            tp = interp1(1:length(X), X, pMove+1+pt:length(X)-pMove+pt);
            xy = corrcoef(tp, AEcgAfterPre(MRwaveLocaAll(p, c)-HWnd:MRwaveLocaAll(p, c)+HWnd, c));
            ct2(round(pt*10+pMove+1)) = xy(2);
            X1 = [X1 tp(:)];
        end
        
        [kk, ctMaxInd] = max(ct2);
        MEcg(MRwaveLocaAll(p, c)-HWnd:MRwaveLocaAll(p, c)+HWnd, c) = X1(:, ctMaxInd);
    end
end

% +++++++++++++ cancellation +++++++++++++++++++++++++++++++++++++++++++++
FEcg = zeros(s2read, chan);
FEcg(:, Flag&1) = AEcgAfterPre(:, Flag&1) - MEcg(:, Flag&1);

% ============= debug ====================================================
if debug
    figure('Color', 'w', 'Name', 'MECG cancellation');
    FlagF = find(Flag);
    for k = 1:length(FlagF)
        subplot(length(FlagF), 1, k)
        plot(AEcgAfterPre(:, FlagF(k)), 'k');
        hold on
        plot(MEcgb(:, FlagF(k)), 'g');
        plot(MEcg(:, FlagF(k)),  'r');
        plot(FEcg(:, FlagF(k)),  'm');
    end
end

function FEcgAfterPre = FEcgPreprocess5(FEcgBeforePre, Flag, debug)
%FECGPREPROCESS FECG de-noising and de-trending
%       by wavelet transform, only the channel with good quality are processed
% 
% $Author: Chengyu Liu and Peng Li 
%           School of Control Science and Engineering,
%           Shandong University
% $Date:    2013.8.23
% 

% +++++++++++++ constants ++++++++++++++++++++++++++++++++++++++++++++++++
[s2read, chan] = size(FEcgBeforePre);

% +++++++++++++ preprocessing channels with high quality +++++++++++++++++
FEcgTrend      = zeros(s2read, chan);
FEcgAfterDen   = zeros(s2read, chan);
for k = find(Flag)
    FEcgAfterDen(:, k) = wden(FEcgBeforePre(:, k), 'rigrsure', 's', 'mln', 4, 'coif5');
    [C, L] = wavedec(FEcgBeforePre(:, k), 6, 'coif5'); % about 8 Hz
    tretp  = upcoef('a', C(1:L(1)), 'coif5', 6);
    indf   = 1 + floor((length(tretp) - s2read)/2) - floor(1*length(wfilters('coif5')));
    FEcgTrend(:, k) = tretp(indf:indf + s2read - 1);
end
FEcgAfterPre = FEcgAfterDen - FEcgTrend;

% ============= debug ====================================================
if debug
    figure('Color', 'w', 'Name', 'Preprocessing of FECG');
    FlagF = find(Flag);
    for k = 1:length(FlagF)
        subplot(length(FlagF), 1, k)
        plot(FEcgBeforePre(:, FlagF(k)), 'k');
        hold on
        plot(FEcgAfterPre(:, FlagF(k)), 'r');
        plot(FEcgTrend(:, FlagF(k)), 'g');
    end
end

function FEcgAfterPre = FEcgPreprocess6(FEcgBeforePre, Flag, debug)
%FECGPREPROCESS FECG de-noising and de-trending
%       by wavelet transform, only the channel with good quality are processed
% 
% $Author: Chengyu Liu and Peng Li 
%           School of Control Science and Engineering,
%           Shandong University
% $Date:    2013.8.23
% 

% +++++++++++++ constants ++++++++++++++++++++++++++++++++++++++++++++++++
[s2read, chan] = size(FEcgBeforePre);

% +++++++++++++ preprocessing channels with high quality +++++++++++++++++
FEcgTrend      = zeros(s2read, chan);
FEcgAfterDen   = zeros(s2read, chan);
for k = find(Flag)
    FEcgAfterDen(:, k) = wden(FEcgBeforePre(:, k), 'rigrsure', 's', 'mln', 4, 'coif5');
    [C, L] = wavedec(FEcgBeforePre(:, k), 6, 'coif5'); % about 8 Hz
    tretp  = upcoef('a', C(1:L(1)), 'coif5', 6);
    indf   = 1 + floor((length(tretp) - s2read)/2) - floor(1*length(wfilters('coif5')));
    FEcgTrend(:, k) = tretp(indf:indf + s2read - 1);
%     [C, L] = wavedec(FEcgBeforePre(:, k), 7, 'coif5'); % about 2 Hz
%     tretp = upcoef('a', C(1:L(1)), 'coif5', 7);
%     indf   = 1 + floor((length(tretp) - s2read)/2)-length(wfilters('coif5'));
%     FEcgTrend(:, k) = tretp(indf:indf + s2read - 1);
end
FEcgAfterPre = FEcgAfterDen - FEcgTrend;

% ============= debug ====================================================
if debug
    figure('Color', 'w', 'Name', 'Preprocessing of FECG');
    FlagF = find(Flag);
    for k = 1:length(FlagF)
        subplot(length(FlagF), 1, k)
        plot(FEcgBeforePre(:, FlagF(k)), 'k');
        hold on
        plot(FEcgAfterPre(:, FlagF(k)), 'r');
        plot(FEcgTrend(:, FlagF(k)), 'g');
    end
end

function FEcgAfterPre = FEcgPreprocess6(FEcgBeforePre, Flag, debug)
%FECGPREPROCESS FECG de-noising and de-trending
%       by wavelet transform, only the channel with good quality are processed
% 
% $Author: Chengyu Liu and Peng Li 
%           School of Control Science and Engineering,
%           Shandong University
% $Date:    2013.8.23
% 

% +++++++++++++ constants ++++++++++++++++++++++++++++++++++++++++++++++++
[s2read, chan] = size(FEcgBeforePre);
Flag = [1 1 1 1];
% +++++++++++++ preprocessing channels with high quality +++++++++++++++++
FEcgTrend      = zeros(s2read, chan);
FEcgAfterDen   = zeros(s2read, chan);
for k = 1:4
    FEcgAfterDen(:, k) = wden(FEcgBeforePre(:, k), 'rigrsure', 's', 'mln', 4, 'coif5');
    [C, L] = wavedec(FEcgAfterDen(:, k), 6, 'coif5'); % about 8 Hz
    tretp  = upcoef('a', C(1:L(1)), 'coif5', 6);
    indf   = 1 + floor((length(tretp) - s2read)/2) - floor(1*length(wfilters('coif5')));
    FEcgTrend(:, k) = tretp(indf:indf + s2read - 1);
end
FEcgAfterPre = FEcgAfterDen - FEcgTrend;

% ============= debug ====================================================
if debug
    figure('Color', 'w', 'Name', 'Preprocessing of FECG');
    FlagF = find(Flag);
    for k = 1:length(FlagF)
        subplot(length(FlagF), 1, k)
        plot(FEcgBeforePre(:, FlagF(k)), 'k');
        hold on
        plot(FEcgAfterPre(:, FlagF(k)), 'r');
        plot(FEcgTrend(:, FlagF(k)), 'g');
    end
end

function [FRwaveLocaAll, FlagF] = FRLoca5(FEcgAfterPre, FlagA, debug)
%FRWAVELOCA R-Wave detection
% 
% $Author: Chengyu Liu and Peng Li 
%           School of Control Science and Engineering,
%           Shandong University
% $Date:    2013.8.24
% 

% +++++++++++++ constants ++++++++++++++++++++++++++++++++++++++++++++++++
[s2read, chan] = size(FEcgAfterPre);

% +++++++++++++ find peaks from each channel +++++++++++++++++++++++++++++
for c = 1:chan
    if FlagA(c)
        eval(['[RPosC' num2str(c) ', fun' num2str(c) '] = FPeak5(FEcgAfterPre(:, c));']);
    else
        eval(['RPosC' num2str(c) ' = 1;']);
    end
end

% +++++++++++++ optimal channel ++++++++++++++++++++++++++++++++++++++++++
std1 = std(diff(RPosC1));
std2 = std(diff(RPosC2));
std3 = std(diff(RPosC3));
std4 = std(diff(RPosC4));
if mean(diff(RPosC1)) < 250
    std1 = inf;
end
if mean(diff(RPosC2)) < 250
    std2 = inf;
end
if mean(diff(RPosC3)) < 250
    std3 = inf;
end
if mean(diff(RPosC4)) < 250
    std4 = inf;
end
[kk, mincha] = min([std1 std2 std3 std4]);

% +++++++++++++ outputs ++++++++++++++++++++++++++++++++++++++++++++++++++
eval(['FpeakPos = RPosC' num2str(mincha) ';']);
eval(['fun = fun' num2str(mincha) ';']);
PeakLoca = zeros(size(FpeakPos));
for k = 1:length(FpeakPos)
    staind = max([1      FpeakPos(k) - 100]);
    endind = min([s2read FpeakPos(k) + 100]);
    [kk, mi] = feval(fun, FEcgAfterPre(staind:endind, mincha));
    PeakLoca(k) = mi + staind - 1;
end
FRwaveLocaAll = zeros(length(PeakLoca), chan);
FRwaveLocaAll(:, mincha) = PeakLoca;
FlagF = zeros(1, 4) & 0;
FlagF(mincha) = 1&1;

% ============= debug ====================================================
if debug
    figure('Color', 'w', 'Name', 'FECG and peaks');
    plot(FEcgAfterPre(:, mincha), 'k');
    hold on
    plot(PeakLoca, FEcgAfterPre(PeakLoca, mincha), 'ro');
    title(['channel: ' num2str(mincha)])
end

function  fetal_QRSAnn_est = FRLoca6(FEcgAfterPre,MRwaveLocaPca,FlagA,FlagF,Much,debug2)
%FRWAVELOCA R-Wave detection
% 
% $Author: Chengyu Liu and Peng Li 
%           School of Control Science and Engineering,
%           Shandong University
% $Date:    2013.8.24
%
% r = 1.1;
% Rmax = 180;
% K = zeros(20,1);
% FRlocaA1 =  FPeak6(FEcgAfterPre(:,find(FlagF==1)),0.1);
% if length(FRlocaA1)>r*length(MRwaveLocaPca) && length(FRlocaA1)<=Rmax
%     K(1) = 1;
% end
% FRlocaA2 =  FPeak6(FEcgAfterPre(:,find(FlagF==1)),0.15);
% if length(FRlocaA2)>r*length(MRwaveLocaPca) && length(FRlocaA2)<=Rmax
%     K(2) = 1;
% end
% FRlocaA3 =  FPeak6(FEcgAfterPre(:,find(FlagF==1)),0.2);
% if length(FRlocaA3)>r*length(MRwaveLocaPca) && length(FRlocaA3)<=Rmax
%     K(3) = 1;
% end
% FRlocaA4 =  FPeak6(FEcgAfterPre(:,find(FlagF==1)),0.25);
% if length(FRlocaA4)>r*length(MRwaveLocaPca) && length(FRlocaA4)<=Rmax
%     K(4) = 1;
% end
% FRlocaA5 =  FPeak6(FEcgAfterPre(:,find(FlagF==1)),0.35);
% if length(FRlocaA5)>r*length(MRwaveLocaPca) && length(FRlocaA5)<=Rmax
%     K(5) = 1;
% end
% FRlocaA6 =  FPeak6(FEcgAfterPre(:,find(FlagF==1)),0.4);
% FRlocaA7 =  FPeak6(FEcgAfterPre(:,find(FlagF==1)),0.45);
% 
% [coef, score] = princomp(zscore(FEcgAfterPre(:,find(FlagA==1)))', 'econ');
% FEcg_prin = coef(:,1); % finding peaks from the first principal component
% FRlocaB1 = FindPeakF1(FEcg_prin,-0.06);
% FRlocaB2 = FindPeakF1(FEcg_prin,-0.05);
% FRlocaB3 = FindPeakF1(FEcg_prin,-0.04);
% FRlocaB4 = FindPeakF1(FEcg_prin,-0.03);
% FRlocaB5 = FindPeakF1(FEcg_prin,-0.02);
% FRlocaB6 = FindPeakF1(FEcg_prin,-0.01);
% FRlocaB7 = FindPeakF1(FEcg_prin,0);
% FRlocaB8 = FindPeakF1(FEcg_prin,0.01);
% FRlocaB9 = FindPeakF1(FEcg_prin,0.02);
% FRlocaB10 = FindPeakF1(FEcg_prin,0.03);
% FRlocaB11 = FindPeakF1(FEcg_prin,0.04);
% FRlocaB12 = FindPeakF1(FEcg_prin,0.05);
% FRlocaB13 = FindPeakF1(FEcg_prin,0.06);

[coef, score] = princomp(zscore(FEcgAfterPre(:,find(FlagA==1)))', 'econ');
FEcg_prin = coef(:,1); % finding peaks from the first principal component
fetal_QRSAnn_est = FindPeakF1(FEcg_prin,0);
p=0.01;
MM =0;
while length(fetal_QRSAnn_est)<1.15*length(MRwaveLocaPca)
    MM =MM+1;
    fetal_QRSAnn_est = [];
    fetal_QRSAnn_est = FindPeakF1(FEcg_prin,p);
    p=p+0.01;
    if MM>7 || length(fetal_QRSAnn_est)>1.4*length(MRwaveLocaPca)
        break
    end
end

if length(fetal_QRSAnn_est)>=180
    if Much
        fetal_QRSAnn_est = [];
        fetal_QRSAnn_est =  FPeak6(FEcgAfterPre(:,find(FlagF==1)),0.35);
        if length(fetal_QRSAnn_est)>=180
            fetal_QRSAnn_est = [];
            fetal_QRSAnn_est =  FPeak6(FEcgAfterPre(:,find(FlagF==1)),0.4);
        end
        if length(fetal_QRSAnn_est)>=180
            fetal_QRSAnn_est = [];
            fetal_QRSAnn_est =  FPeak6(FEcgAfterPre(:,find(FlagF==1)),0.45);
        end
    else
        fetal_QRSAnn_est = [];
        fetal_QRSAnn_est =  FPeak6(FEcgAfterPre(:,find(FlagF==1)),0.15);
    end
end

if length(fetal_QRSAnn_est)>=180
    [coef, score] = princomp(zscore(FEcgAfterPre(:,1:4))', 'econ');
    FEcg_prin = coef(:,1); % finding peaks from the first principal component
    fetal_QRSAnn_est = [];
    fetal_QRSAnn_est = FindPeakF1(FEcg_prin,0);
    p=0;
    MM =0;
    while length(fetal_QRSAnn_est)<1.2*length(MRwaveLocaPca) || length(fetal_QRSAnn_est)>170
        MM =MM+1;
        fetal_QRSAnn_est = [];
        if length(fetal_QRSAnn_est)<1.2*length(MRwaveLocaPca)
            fetal_QRSAnn_est = FindPeakF1(FEcg_prin,p);
            p=p+0.01;
        else if length(fetal_QRSAnn_est)>170
                fetal_QRSAnn_est = FindPeakF1(FEcg_prin,p-0.01);
                p=p-0.01;
            end
        end
        
        if MM>7 || length(fetal_QRSAnn_est)>=120
            break
        end
    end
end
        
if debug2
    figure('Color', 'w', 'Name', 'FECG and peaks');
    plot(FEcg_prin, 'k');
    hold on
    plot(fetal_QRSAnn_est, FEcg_prin(fetal_QRSAnn_est), 'ro');
end
% +++++++++++++ constants ++++++++++++++++++++++++++++++++++++++++++++++++

%%
function [PeakLoca, fun] = FPeak5(x)
%FPEAK          Finding peaks
%               only for FECG
%
% $Author: Chengyu Liu and Peng Li 
%           School of Control Science and Engineering,
%           Shandong University
% $Date:    2013.8.24

% +++++++++++++ constants ++++++++++++++++++++++++++++++++++++++++++++++++
fs = 1000;
N  = length(x);
fratio  = fs/250;                               % Frequence ratio w.r.t. 250hz.360hz;
hwin    = ceil(5*fratio);                       % half window width for parabolic fitting ==20
weights = 1:(-1/hwin):(1/hwin);                 % parabolic fitting weights in half window ==[20*1]
dsw     = sqrt([fliplr(weights), 1, weights])'; % square root of double side weights == [41*1]
xw      = [-((-hwin:hwin).^2)', ones(2*hwin+1, 1)];
xw      = dsw(:, [1 1]) .* xw; % [41*2]
invxw   = inv(xw'*xw)*xw';     % [2*41]

% +++++++++++++ strengthen QRS by parabolic fitting and then log +++++++++
xo    = x;
meanp = mean([max(abs(x(1000:3000))) max(abs(x(5000:7000))) max(abs(x(9000:11000))) max(abs(x(13000:15000)))]);
if max(abs(x(1:50))) > 2*meanp
    x(1:100) = 0;
elseif max(abs(x(end-49:end))) > 2*meanp
    x(end-99:end) = 0;
end
x1 = [x(50:-1:1); x; x(end-49:end)];
N1 = length(x1);
ps2   = zeros(N1, 1);
ps0   = zeros(N1, 1);
for k = (hwin+1):(N1-hwin)
    yw = x1((k-hwin):(k+hwin));
    yw = dsw .* yw;
    th = invxw*yw;
    ps2(k) = th(1);
    ps0(k) = th(2);
end
steF = ps2.*ps0;
steF = steF(51:end-50);
indm    = hankel(1:length(x), length(x):length(x)+99);
envTemp = [steF(50:-1:1); steF; steF(end-49:end)];
envSteF = -1./100.*sum(abs(envTemp(indm)).^3.*log(abs(envTemp(indm)).^3), 2);
envSteF(isnan(envSteF)) = 0;

% +++++++++++++ find peaks in the envelop ++++++++++++++++++++++++++++++++
% 1st step: threshold
sL     = floor(N/10);
envEpi = reshape(envSteF(1:sL*10), sL, 10);
envEpi = sort(envEpi);
threT  = mean(envEpi(end-floor(0.1*sL):end-floor(0.08*sL), :)).*0.3; % 0.3 important!
thre   = min(threT);

% 2nd step: thresholding process
temp = envSteF;
temp(temp <  thre) = 0;
temp(temp >= thre) = 1;

% 3rd step: find peaks
staind = find(diff(temp) == 1) + 1;
endind = find(diff(temp) == -1);

if endind(1) < staind(1)
    staind = [1; staind];
end
if staind(end) > endind(end)
    endind = [endind; N];
end

peakt = [];
for k = 1:length(staind)
    tempSteF = steF(staind(k):endind(k));
    [kk, maxInd] = max(tempSteF);
    peakt = [peakt; maxInd + staind(k) - 1];
end

% +++++++++++++ FP and FN ++++++++++++++++++++++++++++++++++++++++++++++++
% 0th step: direction
x      = xo;
Mareai = repmat(peakt(5:end-4), 1, 200) + repmat(-99:100, length(peakt)-8, 1);
Marea  = x(Mareai);
H      = max(Marea, [], 2)  - mean(Marea, 2);
L      = mean(Marea, 2)     - min(Marea, [], 2);
switch sign(sum(sign(H - L)))
    case -1
        fun = 'min';
    otherwise
        fun = 'max';
end
for p = 1:length(peakt)
    indsta = max([1 peakt(p)-30]);
    indend = min([N peakt(p)+30]);
    [kk, indM] = feval(fun, x(indsta:indend));
    peakt(p)  = indM + indsta - 1;
end

% 1st step: possibly missing beats in the head and tail
% ********  features
tempind  = repmat(peakt(5:end-4), 1, 100) + repmat([-50:49], length(peakt(5:end-4)), 1);
ampind   = feval(fun, x(tempind), [], 2);
amp      = sort(abs(ampind));
if length(amp) > 15
    meanamp   = mean(amp(5:15));
else
    meanamp   = mean(amp);
end
HR       = mean(diff(peakt));
% ********  head
if peakt(1) > 1.55*HR % must missing one beat at the head
    staind = peakt(1) - floor(1.3*HR);
    [kk, maxind] = feval(fun, x(staind:staind+floor(0.6*HR)));
    peakt = [maxind+staind-1; peakt];
elseif peakt(1) > 1.15*HR % possibly missing one beat at the head
    sta = 1;
    if max(abs(x(1:50))) > 2*meanp
        sta = 80;
    end
    [mmax, maxind] = feval(fun, x(sta:floor(0.5*HR)));
    if abs(mmax)   > 0.6*meanamp
        peakt      = [maxind+sta-1; peakt];
    end
end
% ********  tail
if N - peakt(end) > 1.55*HR % must missing one beat at the tail
    staind = peakt(end) + floor(0.7*HR);
    endind = min([N staind+floor(0.6*HR)]);
    [kk, maxind] = feval(fun, x(staind:endind));
    peakt = [peakt; maxind + staind - 1];
elseif N - peakt(end) > 1.15*HR % possibly missing one beat at the tail
    fin = N;
    if max(abs(x(end-49:end))) > 2*meanp
        fin = N-79;
    end
    [mmax, maxind] = feval(fun, x(end-floor(0.5*HR):fin));
    if abs(mmax)   > 0.6*meanamp
        peakt      = [peakt; maxind + N - floor(0.5*HR) - 1];
    end
end

% 2nd step: false positive
meanHR  = mean(diff(peakt));
if meanHR  < 250
    meanHR = 450;
elseif meanHR > 1200
    meanHR    = 550;
end
peak1 = peakt(diff([peakt; 10e6]) > 0.55*meanHR);

% 3rd step: false negative
amp   = sort(abs(steF(peak1)));
if length(amp) > 10
    meanamp = mean(amp(1:10));
else
    meanamp = mean(abs(steF(peak1)));
end
peak1 = [1; peak1; N];
newpeak = [];
errBeat = [];
indn    = find(diff(peak1) > 1.55*meanHR); % position of possibly missing beats
if isempty(indn)
    PeakLoca = unique(peak1(2:end-1));
    % prediction
    RRbeforePredict = diff(PeakLoca);
    partNum = floor(length(RRbeforePredict) / 5);
    MatPeak = reshape(RRbeforePredict(1:partNum*5), 5, partNum);
    MatStd  = std(MatPeak);
    [kk, minind] = min(MatStd);
    tempS   = (minind-1)*5;
    tempE   = minind*5 + 1;
    meanHR  = mean(MatPeak(:, minind));
    
    iCnt  = 1;
    while 1
        if tempE+iCnt > length(PeakLoca)
            break;
        end
        if (PeakLoca(tempE+iCnt) - PeakLoca(tempE+iCnt-1)) < 0.55*meanHR
            PeakLoca(tempE+iCnt) = []; % interplated beat
        elseif (PeakLoca(tempE+iCnt) - PeakLoca(tempE+iCnt-1)) > 1.48*meanHR
            tempRR = x(PeakLoca(tempE+iCnt-1)+floor(0.88*meanHR):PeakLoca(tempE+iCnt-1)+floor(1.18*meanHR));
            [kk, indr] = feval(fun, tempRR);
            PeakLoca = [PeakLoca(1:tempE+iCnt-1); indr+PeakLoca(tempE+iCnt-1)+floor(0.88*meanHR)-1; PeakLoca(tempE+iCnt:end)];
            iCnt = iCnt + 1;      % possibly missing beat
        else
            iCnt = iCnt + 1;
        end
    end
    
    iCnt  = 1;
    while 1
        if tempS-iCnt < 1
            break;
        end
        if (PeakLoca(tempS-iCnt+1) - PeakLoca(tempS-iCnt)) < 0.55*meanHR
            PeakLoca(tempS-iCnt) = []; % interplated beat
        elseif (PeakLoca(tempS-iCnt+1) - PeakLoca(tempS-iCnt)) > 1.48*meanHR
            tempRR = x(PeakLoca(tempS-iCnt+1)-floor(1.18*meanHR):PeakLoca(tempS-iCnt+1)-floor(0.88*meanHR));
            [kk, indr] = feval(fun, tempRR);
            PeakLoca = [PeakLoca(1:tempS-iCnt); indr+PeakLoca(tempS-iCnt+1)-floor(1.18*meanHR)-1; PeakLoca(tempS-iCnt+1:end)];
            % iCnt = iCnt + 1;      % possibly missing beat
        else
            iCnt = iCnt + 1;
        end
    end
else
    k = 1;
    endRev = [];
    while 1
        staRev = peak1(indn(k));
        for iCnt = 1:length(indn) - 1
            endInd = indn(k) + iCnt;
            if k+iCnt > length(indn)
                endRev = peak1(endInd);
                break;
            elseif endInd == indn(k+iCnt);
                errBeat = [errBeat; peak1(endInd)];
            else
                endRev  = peak1(endInd);
                break;
            end
        end
        if isempty(endRev)
            endRev = peak1(indn(end) + 1);
        end
        
        MissNum = ceil(length(staRev:endRev) / meanHR); % number of possibly missing beats
        
        Epi = steF(staRev:endRev);
        epi = floor(length(Epi) / 10);
        Mpi = reshape(Epi(1:epi*10), epi, 10);
        mpi = sort(max(Mpi));
        if abs(mean(mpi(3:end-2))) > 0.9*meanamp
            thre = 0.75;
        elseif abs(mean(mpi(3:end-2))) > 0.7*meanamp
            thre = 0.55;
        elseif abs(mean(mpi(3:end-2))) > 0.5*meanamp
            thre = 0.35;
        elseif abs(mean(mpi(3:end-2))) > 0.3*meanamp
            thre = 0.3;
        else
            thre = 0.2;
        end
        
        for mn = 1:MissNum
            for jCnt = 1:6
                fid  = min([floor(peak1(indn(k)) + (mn+jCnt*0.05)*meanHR) N]);
                if fid < endRev
                    tRR = steF(fid - floor(0.1*jCnt*meanHR):fid);
                    [maxt, maxind] = max(tRR);
                    if abs(maxt) > thre*meanamp
                        newpeak = [newpeak; maxind + fid - floor(0.1*jCnt*meanHR)];
                        break;
                    end
                else
                    if ~isempty(newpeak)
                        if endRev - newpeak(end) < 0.55*meanHR % error beat
                            errBeat = [errBeat; endRev];
                            tRR = steF(fid - floor(0.1*jCnt*meanHR):fid);
                            [maxt, maxind] = max(tRR);
                            if abs(maxt) > 0.6*meanamp
                                newpeak = [newpeak; maxind + fid - floor(0.1*jCnt*meanHR)];
                                break;
                            end
                        end
                    end
                end
            end
        end
        
        if endRev == peak1(indn(end) + 1)
            break;
        end
        
        k = k + iCnt;
        if k > length(indn)
            break;
        end
    end
    
    peak2 = sort([peak1; newpeak]);
    peak2([1 end]) = [];
    if ~isempty(errBeat)
        [kk, IA, kk] = intersect(peak2, errBeat);
        peak2(IA) = [];
    end
    peak2    = unique(peak2);
    PeakLoca = peak2;
    
    % prediction
    RRbeforePredict = diff(PeakLoca);
    partNum = floor(length(RRbeforePredict) / 5);
    MatPeak = reshape(RRbeforePredict(1:partNum*5), 5, partNum);
    MatStd  = std(MatPeak);
    [kk, minind] = min(MatStd);
    tempS   = (minind-1)*5;
    tempE   = minind*5 + 1;
    meanHR  = mean(MatPeak(:, minind));
    
    iCnt  = 1;
    while 1
        if tempE+iCnt > length(PeakLoca)
            break;
        end
        if (PeakLoca(tempE+iCnt) - PeakLoca(tempE+iCnt-1)) < 0.55*meanHR
            PeakLoca(tempE+iCnt) = []; % interplated beat
        elseif (PeakLoca(tempE+iCnt) - PeakLoca(tempE+iCnt-1)) > 1.48*meanHR
            tempRR = x(PeakLoca(tempE+iCnt-1)+floor(0.88*meanHR):PeakLoca(tempE+iCnt-1)+floor(1.18*meanHR));
            [kk, indr] = feval(fun, tempRR);
            PeakLoca = [PeakLoca(1:tempE+iCnt-1); indr+PeakLoca(tempE+iCnt-1)+floor(0.88*meanHR)-1; PeakLoca(tempE+iCnt:end)];
            iCnt = iCnt + 1;      % possibly missing beat
        else
            iCnt = iCnt + 1;
        end
    end
    
    iCnt  = 1;
    while 1
        if tempS-iCnt < 1
            break;
        end
        if (PeakLoca(tempS-iCnt+1) - PeakLoca(tempS-iCnt)) < 0.55*meanHR
            PeakLoca(tempS-iCnt) = []; % interplated beat
        elseif (PeakLoca(tempS-iCnt+1) - PeakLoca(tempS-iCnt)) > 1.48*meanHR
            tempRR = x(PeakLoca(tempS-iCnt+1)-floor(1.18*meanHR):PeakLoca(tempS-iCnt+1)-floor(0.88*meanHR));
            [kk, indr] = feval(fun, tempRR);
            PeakLoca = [PeakLoca(1:tempS-iCnt); indr+PeakLoca(tempS-iCnt+1)-floor(1.18*meanHR)-1; PeakLoca(tempS-iCnt+1:end)];
            % iCnt = iCnt + 1;      % possibly missing beat
        else
            iCnt = iCnt + 1;
        end
    end
end

% +++++++++++++ TN +++++++++++++++++++++++++++++++++++++++++++++++++++++++
RR   = diff(PeakLoca);
HR   = mean(RR);
sRra = RR(1:end-1)./RR(2:end);
indn = (sRra >= 1.35);
if any(indn)
    indtn = find(indn);
    for k = 1:length(indtn)
        if indtn(k) ~= 1 && ((PeakLoca(indtn(k)) - PeakLoca(indtn(k)-1))/HR <= 1.3 || (PeakLoca(indtn(k)) - PeakLoca(indtn(k)-1))/HR >= 0.7)
            [kk, tp] = feval(fun, x(PeakLoca(indtn(k)) + round(0.8*HR):PeakLoca(indtn(k)) + round(1.2*HR)));
            PeakLoca(indtn(k)+1) = tp + PeakLoca(indtn(k)) + round(0.8*HR) - 1;
        elseif indtn(k) ~= 1
            [kk, tp] = feval(fun, x(PeakLoca(indtn(k)+1) - round(1.2*HR):PeakLoca(indtn(k)+1) - round(0.8*HR)));
            PeakLoca(indtn(k)) = tp + PeakLoca(indtn(k)+1) - round(1.2*HR) - 1;
        end
    end
end

% validate head and tail
if (PeakLoca(3)-PeakLoca(2))/(PeakLoca(2)-PeakLoca(1)) > 1.3
    sta = max([1 PeakLoca(2)-round(1.15*mean(diff(PeakLoca)))]);
    if PeakLoca(2)-round(0.85*mean(diff(PeakLoca))) > 1
        [mm, ind] = feval(fun, x(sta:PeakLoca(2)-round(0.85*mean(diff(PeakLoca)))));
        if abs(mm) > 0.8*mean(x(PeakLoca))
            PeakLoca(1) = ind + sta - 1;
        end
    end
end
if (PeakLoca(end-2)-PeakLoca(end-1))/(PeakLoca(end-1)-PeakLoca(end)) > 1.3
    fin = min([N PeakLoca(end-1)+round(1.15*mean(diff(PeakLoca)))]);
    if PeakLoca(end-1)+round(0.85*mean(diff(PeakLoca))) < N
        [mm, ind] = feval(fun, x(PeakLoca(end-1)+round(0.85*mean(diff(PeakLoca))):fin));
        if abs(mm) > 0.8*mean(x(PeakLoca))
            PeakLoca(end) = ind + PeakLoca(end-1)+round(0.85*mean(diff(PeakLoca))) - 1;
        end
    end
end

function [PeakLoca, fun] = FPeak6(x,coin)
%FPEAK          Finding peaks
%               only for FECG
%
% $Author: Chengyu Liu and Peng Li 
%           School of Control Science and Engineering,
%           Shandong University
% $Date:    2013.8.24

% +++++++++++++ constants ++++++++++++++++++++++++++++++++++++++++++++++++
fs = 1000;
N  = length(x);
fratio  = fs/250;                               % Frequence ratio w.r.t. 250hz.360hz;
hwin    = ceil(5*fratio);                       % half window width for parabolic fitting ==20
weights = 1:(-1/hwin):(1/hwin);                 % parabolic fitting weights in half window ==[20*1]
dsw     = sqrt([fliplr(weights), 1, weights])'; % square root of double side weights == [41*1]
xw      = [-((-hwin:hwin).^2)', ones(2*hwin+1, 1)];
xw      = dsw(:, [1 1]) .* xw; % [41*2]
invxw   = inv(xw'*xw)*xw';     % [2*41]

% +++++++++++++ strengthen QRS by parabolic fitting and then log +++++++++
xo    = x;
meanp = mean([max(abs(x(1000:3000))) max(abs(x(5000:7000))) max(abs(x(9000:11000))) max(abs(x(13000:15000)))]);
if max(abs(x(1:50))) > 2*meanp
    x(1:100) = 0;
elseif max(abs(x(end-49:end))) > 2*meanp
    x(end-99:end) = 0;
end
x1 = [x(50:-1:1); x; x(end-49:end)];
N1 = length(x1);
ps2   = zeros(N1, 1);
ps0   = zeros(N1, 1);
for k = (hwin+1):(N1-hwin)
    yw = x1((k-hwin):(k+hwin));
    yw = dsw .* yw;
    th = invxw*yw;
    ps2(k) = th(1);
    ps0(k) = th(2);
end
steF = ps2.*ps0;
steF = steF(51:end-50);
indm    = hankel(1:length(x), length(x):length(x)+99);
envTemp = [steF(50:-1:1); steF; steF(end-49:end)];
envSteF = -1./100.*sum(abs(envTemp(indm)).^3.*log(abs(envTemp(indm)).^3), 2);
envSteF(isnan(envSteF)) = 0;

% +++++++++++++ find peaks in the envelop ++++++++++++++++++++++++++++++++
% 1st step: threshold
sL     = floor(N/10);
envEpi = reshape(envSteF(1:sL*10), sL, 10);
envEpi = sort(envEpi);
threT  = mean(envEpi(end-floor(0.1*sL):end-floor(0.08*sL), :)).*coin; % 0.3 important!
thre   = min(threT);

% 2nd step: thresholding process
temp = envSteF;
temp(temp <  thre) = 0;
temp(temp >= thre) = 1;

% 3rd step: find peaks
staind = find(diff(temp) == 1) + 1;
endind = find(diff(temp) == -1);

if endind(1) < staind(1)
    staind = [1; staind];
end
if staind(end) > endind(end)
    endind = [endind; N];
end

peakt = [];
for k = 1:length(staind)
    tempSteF = steF(staind(k):endind(k));
    [kk, maxInd] = max(tempSteF);
    peakt = [peakt; maxInd + staind(k) - 1];
end

% +++++++++++++ FP and FN ++++++++++++++++++++++++++++++++++++++++++++++++
% 0th step: direction
x      = xo;
Mareai = repmat(peakt(5:end-4), 1, 200) + repmat(-99:100, length(peakt)-8, 1);
Marea  = x(Mareai);
H      = max(Marea, [], 2)  - mean(Marea, 2);
L      = mean(Marea, 2)     - min(Marea, [], 2);
switch sign(sum(sign(H - L)))
    case -1
        fun = 'min';
    otherwise
        fun = 'max';
end
for p = 1:length(peakt)
    indsta = max([1 peakt(p)-30]);
    indend = min([N peakt(p)+30]);
    [kk, indM] = feval(fun, x(indsta:indend));
    peakt(p)  = indM + indsta - 1;
end

% 1st step: possibly missing beats in the head and tail
% ********  features
tempind  = repmat(peakt(5:end-4), 1, 100) + repmat([-50:49], length(peakt(5:end-4)), 1);
ampind   = feval(fun, x(tempind), [], 2);
amp      = sort(abs(ampind));
if length(amp) > 15
    meanamp   = mean(amp(5:15));
else
    meanamp   = mean(amp);
end
HR       = mean(diff(peakt));
% ********  head
if peakt(1) > 1.55*HR % must missing one beat at the head
    staind = peakt(1) - floor(1.3*HR);
    [kk, maxind] = feval(fun, x(staind:staind+floor(0.6*HR)));
    peakt = [maxind+staind-1; peakt];
elseif peakt(1) > 1.15*HR % possibly missing one beat at the head
    sta = 1;
    if max(abs(x(1:50))) > 2*meanp
        sta = 80;
    end
    [mmax, maxind] = feval(fun, x(sta:floor(0.5*HR)));
    if abs(mmax)   > 0.6*meanamp
        peakt      = [maxind+sta-1; peakt];
    end
end
% ********  tail
if N - peakt(end) > 1.55*HR % must missing one beat at the tail
    staind = peakt(end) + floor(0.7*HR);
    endind = min([N staind+floor(0.6*HR)]);
    [kk, maxind] = feval(fun, x(staind:endind));
    peakt = [peakt; maxind + staind - 1];
elseif N - peakt(end) > 1.15*HR % possibly missing one beat at the tail
    fin = N;
    if max(abs(x(end-49:end))) > 2*meanp
        fin = N-79;
    end
    [mmax, maxind] = feval(fun, x(end-floor(0.5*HR):fin));
    if abs(mmax)   > 0.6*meanamp
        peakt      = [peakt; maxind + N - floor(0.5*HR) - 1];
    end
end

% 2nd step: false positive
meanHR  = mean(diff(peakt));
if meanHR  < 250
    meanHR = 450;
elseif meanHR > 1200
    meanHR    = 550;
end
peak1 = peakt(diff([peakt; 10e6]) > 0.55*meanHR);

% 3rd step: false negative
amp   = sort(abs(steF(peak1)));
if length(amp) > 10
    meanamp = mean(amp(1:10));
else
    meanamp = mean(abs(steF(peak1)));
end
peak1 = [1; peak1; N];
newpeak = [];
errBeat = [];
indn    = find(diff(peak1) > 1.55*meanHR); % position of possibly missing beats
if isempty(indn)
    PeakLoca = unique(peak1(2:end-1));
    % prediction
    RRbeforePredict = diff(PeakLoca);
    partNum = floor(length(RRbeforePredict) / 5);
    MatPeak = reshape(RRbeforePredict(1:partNum*5), 5, partNum);
    MatStd  = std(MatPeak);
    [kk, minind] = min(MatStd);
    tempS   = (minind-1)*5;
    tempE   = minind*5 + 1;
    meanHR  = mean(MatPeak(:, minind));
    
    iCnt  = 1;
    while 1
        if tempE+iCnt > length(PeakLoca)
            break;
        end
        if (PeakLoca(tempE+iCnt) - PeakLoca(tempE+iCnt-1)) < 0.55*meanHR
            PeakLoca(tempE+iCnt) = []; % interplated beat
        elseif (PeakLoca(tempE+iCnt) - PeakLoca(tempE+iCnt-1)) > 1.48*meanHR
            tempRR = x(PeakLoca(tempE+iCnt-1)+floor(0.88*meanHR):PeakLoca(tempE+iCnt-1)+floor(1.18*meanHR));
            [kk, indr] = feval(fun, tempRR);
            PeakLoca = [PeakLoca(1:tempE+iCnt-1); indr+PeakLoca(tempE+iCnt-1)+floor(0.88*meanHR)-1; PeakLoca(tempE+iCnt:end)];
            iCnt = iCnt + 1;      % possibly missing beat
        else
            iCnt = iCnt + 1;
        end
    end
    
    iCnt  = 1;
    while 1
        if tempS-iCnt < 1
            break;
        end
        if (PeakLoca(tempS-iCnt+1) - PeakLoca(tempS-iCnt)) < 0.55*meanHR
            PeakLoca(tempS-iCnt) = []; % interplated beat
        elseif (PeakLoca(tempS-iCnt+1) - PeakLoca(tempS-iCnt)) > 1.48*meanHR
            tempRR = x(PeakLoca(tempS-iCnt+1)-floor(1.18*meanHR):PeakLoca(tempS-iCnt+1)-floor(0.88*meanHR));
            [kk, indr] = feval(fun, tempRR);
            PeakLoca = [PeakLoca(1:tempS-iCnt); indr+PeakLoca(tempS-iCnt+1)-floor(1.18*meanHR)-1; PeakLoca(tempS-iCnt+1:end)];
            % iCnt = iCnt + 1;      % possibly missing beat
        else
            iCnt = iCnt + 1;
        end
    end
else
    k = 1;
    endRev = [];
    while 1
        staRev = peak1(indn(k));
        for iCnt = 1:length(indn) - 1
            endInd = indn(k) + iCnt;
            if k+iCnt > length(indn)
                endRev = peak1(endInd);
                break;
            elseif endInd == indn(k+iCnt);
                errBeat = [errBeat; peak1(endInd)];
            else
                endRev  = peak1(endInd);
                break;
            end
        end
        if isempty(endRev)
            endRev = peak1(indn(end) + 1);
        end
        
        MissNum = ceil(length(staRev:endRev) / meanHR); % number of possibly missing beats
        
        Epi = steF(staRev:endRev);
        epi = floor(length(Epi) / 10);
        Mpi = reshape(Epi(1:epi*10), epi, 10);
        mpi = sort(max(Mpi));
        if abs(mean(mpi(3:end-2))) > 0.9*meanamp
            thre = 0.75;
        elseif abs(mean(mpi(3:end-2))) > 0.7*meanamp
            thre = 0.55;
        elseif abs(mean(mpi(3:end-2))) > 0.5*meanamp
            thre = 0.35;
        elseif abs(mean(mpi(3:end-2))) > 0.3*meanamp
            thre = 0.3;
        else
            thre = 0.2;
        end
        
        for mn = 1:MissNum
            for jCnt = 1:6
                fid  = min([floor(peak1(indn(k)) + (mn+jCnt*0.05)*meanHR) N]);
                if fid < endRev
                    tRR = steF(fid - floor(0.1*jCnt*meanHR):fid);
                    [maxt, maxind] = max(tRR);
                    if abs(maxt) > thre*meanamp
                        newpeak = [newpeak; maxind + fid - floor(0.1*jCnt*meanHR)];
                        break;
                    end
                else
                    if ~isempty(newpeak)
                        if endRev - newpeak(end) < 0.55*meanHR % error beat
                            errBeat = [errBeat; endRev];
                            tRR = steF(fid - floor(0.1*jCnt*meanHR):fid);
                            [maxt, maxind] = max(tRR);
                            if abs(maxt) > 0.6*meanamp
                                newpeak = [newpeak; maxind + fid - floor(0.1*jCnt*meanHR)];
                                break;
                            end
                        end
                    end
                end
            end
        end
        
        if endRev == peak1(indn(end) + 1)
            break;
        end
        
        k = k + iCnt;
        if k > length(indn)
            break;
        end
    end
    
    peak2 = sort([peak1; newpeak]);
    peak2([1 end]) = [];
    if ~isempty(errBeat)
        [kk, IA, kk] = intersect(peak2, errBeat);
        peak2(IA) = [];
    end
    peak2    = unique(peak2);
    PeakLoca = peak2;
    
    % prediction
    RRbeforePredict = diff(PeakLoca);
    partNum = floor(length(RRbeforePredict) / 5);
    MatPeak = reshape(RRbeforePredict(1:partNum*5), 5, partNum);
    MatStd  = std(MatPeak);
    [kk, minind] = min(MatStd);
    tempS   = (minind-1)*5;
    tempE   = minind*5 + 1;
    meanHR  = mean(MatPeak(:, minind));
    
    iCnt  = 1;
    while 1
        if tempE+iCnt > length(PeakLoca)
            break;
        end
        if (PeakLoca(tempE+iCnt) - PeakLoca(tempE+iCnt-1)) < 0.55*meanHR
            PeakLoca(tempE+iCnt) = []; % interplated beat
        elseif (PeakLoca(tempE+iCnt) - PeakLoca(tempE+iCnt-1)) > 1.48*meanHR
            tempRR = x(PeakLoca(tempE+iCnt-1)+floor(0.88*meanHR):PeakLoca(tempE+iCnt-1)+floor(1.18*meanHR));
            [kk, indr] = feval(fun, tempRR);
            PeakLoca = [PeakLoca(1:tempE+iCnt-1); indr+PeakLoca(tempE+iCnt-1)+floor(0.88*meanHR)-1; PeakLoca(tempE+iCnt:end)];
            iCnt = iCnt + 1;      % possibly missing beat
        else
            iCnt = iCnt + 1;
        end
    end
    
    iCnt  = 1;
    while 1
        if tempS-iCnt < 1
            break;
        end
        if (PeakLoca(tempS-iCnt+1) - PeakLoca(tempS-iCnt)) < 0.55*meanHR
            PeakLoca(tempS-iCnt) = []; % interplated beat
        elseif (PeakLoca(tempS-iCnt+1) - PeakLoca(tempS-iCnt)) > 1.48*meanHR
            tempRR = x(PeakLoca(tempS-iCnt+1)-floor(1.18*meanHR):PeakLoca(tempS-iCnt+1)-floor(0.88*meanHR));
            [kk, indr] = feval(fun, tempRR);
            PeakLoca = [PeakLoca(1:tempS-iCnt); indr+PeakLoca(tempS-iCnt+1)-floor(1.18*meanHR)-1; PeakLoca(tempS-iCnt+1:end)];
            % iCnt = iCnt + 1;      % possibly missing beat
        else
            iCnt = iCnt + 1;
        end
    end
end

% +++++++++++++ TN +++++++++++++++++++++++++++++++++++++++++++++++++++++++
RR   = diff(PeakLoca);
HR   = mean(RR);
sRra = RR(1:end-1)./RR(2:end);
indn = (sRra >= 1.35);
if any(indn)
    indtn = find(indn);
    for k = 1:length(indtn)
        if indtn(k) ~= 1 && ((PeakLoca(indtn(k)) - PeakLoca(indtn(k)-1))/HR <= 1.3 || (PeakLoca(indtn(k)) - PeakLoca(indtn(k)-1))/HR >= 0.7)
            [kk, tp] = feval(fun, x(PeakLoca(indtn(k)) + round(0.8*HR):PeakLoca(indtn(k)) + round(1.2*HR)));
            PeakLoca(indtn(k)+1) = tp + PeakLoca(indtn(k)) + round(0.8*HR) - 1;
        elseif indtn(k) ~= 1
            [kk, tp] = feval(fun, x(PeakLoca(indtn(k)+1) - round(1.2*HR):PeakLoca(indtn(k)+1) - round(0.8*HR)));
            PeakLoca(indtn(k)) = tp + PeakLoca(indtn(k)+1) - round(1.2*HR) - 1;
        end
    end
end

% validate head and tail
if (PeakLoca(3)-PeakLoca(2))/(PeakLoca(2)-PeakLoca(1)) > 1.3
    sta = max([1 PeakLoca(2)-round(1.15*mean(diff(PeakLoca)))]);
    if PeakLoca(2)-round(0.85*mean(diff(PeakLoca))) > 1
        [mm, ind] = feval(fun, x(sta:PeakLoca(2)-round(0.85*mean(diff(PeakLoca)))));
        if abs(mm) > 0.8*mean(x(PeakLoca))
            PeakLoca(1) = ind + sta - 1;
        end
    end
end
if (PeakLoca(end-2)-PeakLoca(end-1))/(PeakLoca(end-1)-PeakLoca(end)) > 1.3
    fin = min([N PeakLoca(end-1)+round(1.15*mean(diff(PeakLoca)))]);
    if PeakLoca(end-1)+round(0.85*mean(diff(PeakLoca))) < N
        [mm, ind] = feval(fun, x(PeakLoca(end-1)+round(0.85*mean(diff(PeakLoca))):fin));
        if abs(mm) > 0.8*mean(x(PeakLoca))
            PeakLoca(end) = ind + PeakLoca(end-1)+round(0.85*mean(diff(PeakLoca))) - 1;
        end
    end
end

function SampEn = sampen2(x, m, r)
% SAMPEN	
%           Ref.    Richman JS, Moorman JR
%                   Physiological time-series analysis using approximate
%                   entropy and sample entropy
%                   Am J Physil Heart Circ Physiol, 2000
% 
% $Author:
% $Date:    2011.5.4
% $Modified:2012.3.11
%           using pdist for saving time for short series

N    = length(x);
indm = hankel(1:N-m, N-m:N-1); % M
inda = hankel(1:N-m, N-m:N);   % m+1
ym   = x(indm);
if m  == 1
    ym = ym(:);
end
ya   = x(inda);

% using pdist for saving time
% but need a large memory
cheb = pdist(ym, 'chebychev'); % maximum coordinate difference
cm   = sum(cheb <= r)*2 / (size(ym, 1)*(size(ym, 1)-1));

cheb = pdist(ya, 'chebychev');
ca   = sum(cheb <= r)*2 / (size(ya, 1)*(size(ya, 1)-1));
SampEn = -log(sum(ca)/sum(cm));


function PeakLoca = FindPeakF1(x,p)
temp = x;
fs=1000;
s = filtbyfft(x-mean(x),fs, [0.5 250]);
N=length(s);
fratio = fs/250; % Frequence ratio w.r.t. 250hz.360hz;
hwin=ceil(5*fratio); % half window width for parabolic fitting ==20
weights=1:(-1/hwin):(1/hwin); % parabolic fitting weights in half window ==[20*1] 1.0000    0.9500    0.9000    0.8500    0.8000    0.7500    0.7000    0.6500    0.6000    0.5500    0.5000    0.4500    0.4000    0.3500    0.3000    0.2500    0.2000    0.1500    0.1000    0.0500
dsw = sqrt([fliplr(weights), 1, weights])'; % square root of double side weights == [41*1] 
ps2 = zeros(size(s));% 
ps0 = zeros(size(s));
xw = [-[(-hwin:hwin).^2]', ones(2*hwin+1,1)];
xw = dsw(:,[1 1]) .* xw; % [41*2]
invxw = inv(xw'*xw)*xw'; % [2*41]
for k=(hwin+1):(N-hwin)
  yw = s((k-hwin):(k+hwin));
  yw = dsw .* yw;
  th = invxw*yw;
  ps2(k) = th(1);
  ps0(k) = th(2);
end
pth = ps2.*ps0;
% END of indicator signal computation
%%
% R location
PTc = zeros(N,1);
kpt = 0; % valid peak number
pth0 = pth; % Store original pth for missed peaks recovery
srtlen = min(10000*fratio, length(pth));
sortedpth = sort(pth(1:srtlen));
seuil = sortedpth(round(srtlen*0.925));%0.925
pth(find(pth<seuil)) = 0;
cnth = round((0.24-p)*fs);%==240
debut = 1;
fin = 0;
for k=(1+cnth):N-cnth
  if pth(k) & ~any(pth((k-cnth):(k-1)))
    debut = k;
  end
  if pth(k) & ~any(pth((k+1):(k+cnth)))
    fin = k;
    [dum, ind] = max(pth(debut:fin));
    ind = ind + debut - 1;
    kpt = kpt+1;
    PTc(kpt) = ind;
  end
end
picind = PTc(1:kpt); %peak location
srtlen = min(10000*fratio, kpt);
dpic = diff(picind(1:srtlen));%peak sery
sorteddpic = sort(dpic);
typicnum = median(sorteddpic(1:ceil(srtlen/3)));
beginexind = BeginPeakRecovery(picind(1), pth0, typicnum, seuil);
picind = [sort(beginexind); picind];
%%
% These 3 lines have to be redone since now picind may have been changed.
dpic = diff(picind(1:srtlen));
sorteddpic = sort(dpic);
typicnum = median(sorteddpic(1:ceil(srtlen/3)));

indmiss = find(dpic>typicnum*1.5);
if ~isempty(indmiss)
  misscase = length(indmiss);
  extraind = cell(misscase,1);
  for km=1:length(indmiss)
    extraind{km} = PeakRecovery(picind(indmiss(km)), picind(indmiss(km)+1), pth0, typicnum);
  end
  vecextraind = cell2mat(extraind);
  keptind = find(pth0(vecextraind)>0.3*seuil);
  picind = sort([picind; vecextraind(keptind)]);
end
if picind(1)<20
    peak1=picind(2:end);
else
    peak1=picind;
end


% false negative
meanHR  = mean(diff(peak1));
newpeak = [];
indn    = find(diff(peak1) > 1.5*meanHR); % position of possibly missing beats
for k   = 1:length(indn)
    MissNum = ceil(length(peak1(indn(k)):peak1(indn(k) + 1)) / meanHR); % number of possibly missing beats
    for mn  = 1:MissNum
        fid = floor(peak1(indn(k)) + mn*1.2*meanHR);
        if fid  > length(x)
            fid = length(x);
        end
        tRR = x(floor(peak1(indn(k)) + (mn-1)*1.2*meanHR):fid);
        [maxn, indt] = max(temp(end-floor(0.4*meanHR):end));
        newpeak = [newpeak; indt + floor(peak1(indn(k)) + mn*1.2*meanHR) - floor(0.4*meanHR) - 1];
    end
end
peak2 = sort([peak1; newpeak]);

% false positive
peak3 = peak2;
peak3(diff(peak3) < 0.7*mean(diff(peak3))) = [];

% real peak
PeakLoca = [];
for k   = 1:length(peak3)
    inf = peak3(k) - 200;
    if inf  < 1
        inf = 1;
    end
    ine = peak3(k) + 200;
    if ine  > length(x)
        ine = length(x);
    end
    [maxp, indp] = max(x(inf:ine));
    PeakLoca = [PeakLoca; indp + inf - 1];
end
PeakLoca = unique(PeakLoca);

% prediction
RRbeforePredict = diff(PeakLoca);
partNum = floor(length(RRbeforePredict) / 5);
MatPeak = reshape(RRbeforePredict(1:partNum*5), 5, partNum);
MatStd  = std(MatPeak);
[minstd, minind] = min(MatStd);
tempS   = (minind-1)*5;
tempE   = minind*5 + 1;
meanHR  = mean(MatPeak(:, minind));
lenRR   = length(PeakLoca);

iCnt  = 1;
while 1
    if tempE+iCnt > length(PeakLoca)
        break;
    end
    if (PeakLoca(tempE+iCnt) - PeakLoca(tempE+iCnt-1)) < 0.55*meanHR
        PeakLoca(tempE+iCnt) = []; % interplated beat
    elseif (PeakLoca(tempE+iCnt) - PeakLoca(tempE+iCnt-1)) > 1.48*meanHR
        tempRR = x(PeakLoca(tempE+iCnt-1)+floor(0.88*meanHR):PeakLoca(tempE+iCnt-1)+floor(1.18*meanHR));
        [maxr, indr] = max(tempRR);
        PeakLoca = [PeakLoca(1:tempE+iCnt-1); indr+PeakLoca(tempE+iCnt-1)+floor(0.88*meanHR)-1; PeakLoca(tempE+iCnt:end)];
        iCnt = iCnt + 1;      % possibly missing beat
    else
        iCnt = iCnt + 1;
    end
end

iCnt  = 1;
while 1
    if tempS-iCnt < 1
        break;
    end
    if (PeakLoca(tempS-iCnt+1) - PeakLoca(tempS-iCnt)) < 0.55*meanHR
        PeakLoca(tempS-iCnt) = []; % interplated beat
    elseif (PeakLoca(tempS-iCnt+1) - PeakLoca(tempS-iCnt)) > 1.48*meanHR
        tempRR = x(PeakLoca(tempS-iCnt+1)-floor(1.18*meanHR):PeakLoca(tempS-iCnt+1)-floor(0.88*meanHR));
        [maxr, indr] = max(tempRR);
        PeakLoca = [PeakLoca(1:tempS-iCnt); indr+PeakLoca(tempS-iCnt+1)-floor(1.18*meanHR)-1; PeakLoca(tempS-iCnt+1:end)];
        % iCnt = iCnt + 1;      % possibly missing beat
    else
        iCnt = iCnt + 1;
    end
end

%%
function exind = PeakRecovery(ind1, ind2, pth, typicnum)
% Recover missed peaks between two detected peaks
hnum = ceil(0.5*typicnum);
[dum, maxind] = max(pth((ind1+hnum):(ind2-hnum)));
maxindglobal = maxind + ind1+hnum - 1;
exind =  maxindglobal;

if (maxindglobal-ind1)>typicnum*1.5
  exind = [PeakRecovery(ind1, maxindglobal, pth, typicnum); exind];
end

if (ind2-maxindglobal)>typicnum*1.5
  exind = [exind; PeakRecovery(maxindglobal, ind2, pth, typicnum)];
end 

%%
function exind = BeginPeakRecovery(ind1, pth0, typicnum, seuil)
% Recover missed peaks at the beginning of the signal
if ind1>typicnum*0.7 
  [maxv, maxi] = max(pth0(1:ceil(ind1-typicnum*0.3)));
  if maxv>seuil*0.6
%     exind = [maxi; BeginPeakRecovery(maxi, pth0, typicnum, seuil)];
      exind = maxi;
  else
    exind = [];
  end
else
  exind = [];
end

function xf = filtbyfft(x, fs, passband)
%FILTBYFFT: filter by FFT
% x: signal vector, fs: sampling frequency,  passband: passband interval
%
% Author: Qinghua Zhang
% Copyright 2005 INRIA

if nargin<3
  error('3 input arguments are required. ')
end

%if fs<=2*fcut
%  error('Cut-off frequency must be smaller than half of sampling frequency.')
%end

if length(passband)~=2
  error('Passband must be a vector of two components specifying the passband interval.')
end

passband(1) = max(passband(1), 0);
passband(2) = min(passband(2), 0.5*fs);

N = length(x);
y = fft(x);

lowicut = round(passband(1)*N/fs);
lowmirror = N-lowicut+2;

highicut =  round(passband(2)*N/fs);
highmirror = N-highicut+2;

y([1:(lowicut-1) (lowmirror+1):end])=0;
y((highicut+1):(highmirror-1))=0;


xf = ifft(y);