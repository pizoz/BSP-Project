function [fetal_QRSAnn_est,QT_Interval] = physionet2013(tm,ECG)

% Copyright (C) 2014 Alessia Dess�, Danilo Pani, Luigi Raffo
% DIEE�Department of Electrical and Electronic Engineering, University of 
% Cagliari, 09124 Cagliari, Italy
% This program is free software; you can redistribute it and/or 
% modify it under the terms of the GNU General Public License as 
% published by the Free Software Foundation; either version 2 of 
% the License, or (at your option) any later version.
% This program is distributed in the hope that it will be useful, 
% but WITHOUT ANY WARRANTY; without even the implied warranty of 
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU 
% General Public License for more details.
% You should have received a copy of the GNU General Public License 
% along with this program; if not, write to the Free Software Foundation, 
% Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

% To contact the authors:
% alessia.dessi@diee.unica.it, danilo.pani@diee.unica.it,
% luigi@diee.unica.it
% Address:  Department of Electrical and Electronic Engineering, 
% University of Cagliari,Via Marengo 3 - 09123 Cagliari, Italy

% Please cite the following article when using this code:
% A. Dess�, D. Pani, L. Raffo, "An advanced algorithm for fetal heart rate 
% estimation from non-invasive low electrode density recordings",
% Physiological Measurement, 2014


% This algorithm has been developed starting from the template algorithm 
% for Physionet/CinC competition 2013 (Author: Joachim Behar - 
% IPMG Oxford (joachim.behar@eng.ox.ac.uk), Last updated: March 3, 2013
% Ikaro Silva). The function prototype is the same of the competition:
% [fetal_QRSAnn_est,QT_Interval] = physionet2013(tm,ECG) where the inputs and outputs are specified
% below.
% inputs:
%   ECG: 4x60000 (4 channels and 1min of signal at 1000Hz) matrix of
%   abdominal ECG channels.
%   tm : Nx1 vector of time in milliseconds
% output:
%   FQRS: FQRS markers in seconds. Each marker indicates the position of one
%   of the FQRS detected by the algorithm.
%   QT_Interval:   1x1 estimated fetal QT duration (enter NaN or 0 if you do wish to calculate)

%% the trustworthySCORE variable can be set as function output. It is computed
% according to the results of the pseudo-periodicity corrector
% trustworthySCORE=3 trustworthy result
% trustworthySCORE=2 reasonably trustworthy result
% trustworthySCORE=1 not trustworthy result
    

% ---- check size of ECG ----
if size(ECG,1)>size(ECG,2)
    ECG = ECG';
end


fs      = 1000;             % sampling frequency
fproc   = 250;              % processing frequency
N       = size(ECG,1);      % number of abdominal channels
debug   = 0;                % enter debug mode?

%% ---- PREPROCESSING ----
[FilteredECG, original_d] = preprocessing(ECG,fs,fproc);


%% MATERNAL PEAKS DETECTION
picchi_globali={};
percentuale_soglia=0.4;  %percentage threshold
intorno_sovrasoglia=4;    %number of samples over threshold

for tu=1:size(original_d,1)
     x(tu,:)=resample(original_d(tu,:),250,1000);
     y(tu,:)=x(tu,:);
     uscita(tu,:)=PanTompkinsAlgorithm(y(tu,:)'); %PanTompkins algorithm
     [qrs]=trova_picchi_pan_tompkins(uscita(tu,:), percentuale_soglia,intorno_sovrasoglia);
     tb=find(qrs<1);
     if(length(tb)>0)
         qrs(tb)=[];
     end
     if(length(qrs)>0)
         picchi_globali(tu,1)={qrs};
     end
end
soglia=60; %pseudo-periodicity threshold
[picchi]=analisi_periodicita_picchi2(picchi_globali,soglia);  %multichannel pseudo-periodicity correction and channel selection
th_periodicity=60;% threshold of single-channel pseudo-periodicity corrector
forget=1/4;% forgetting factor single-channel pseudo-periodicity corrector 
delay=0;
[occtmp,count_removed,count_added]=periodicity_correction_v2(picchi,length(x(1,:)),th_periodicity,forget, delay,1,1); %final periodicity correction
mann=occtmp;  %maternal peaks


%% EXTRACTION OF MATERNAL AVERAGE TEMPLATES
dim_intervallo=60;   %time interval in seconds
dim_intervallo=dim_intervallo*250;  %@250Hz
numero_intervalli=floor(length(FilteredECG(1,:))/dim_intervallo); %number of intervals
if(numero_intervalli==0)
    numero_intervalli=1;
end
noise=ones(N,numero_intervalli);
th_fus=0.9; %template fusion threshold
th_cross=0.8; %template cross-correlation threshold
th_creat=0.85; %template creation threshold
l_wind=200*8; %1000Hz*8 = template @8000Hz
struct_template={};
struct_annotazioni={};

%resampling @8kHz
for di=1:N
    prova(:,di)=resample(original_d(di,:)',8000,1000);
end
up_original=prova';

Apost={};

for di=1:numero_intervalli
    for numb_chann=1:N
        [apost,occ_fn]=PeakDetection...
        (mann, l_wind, th_cross,th_creat,th_fus,up_original(numb_chann,4*8*((di-1)*dim_intervallo)+1:4*8*(di*dim_intervallo)));
        if(isempty(occ_fn))
            noise(numb_chann,di)=1;
            apost=[];
        else
            noise(numb_chann,di)=0;
        end
        Apost(numb_chann, di)={apost};
    end
end

battiti_materni=mann; %maternal peaks @250

%% SUBTRACTION OF THE MATERNAL AVERAGE PEAKS
alarm=0;
FECG={};
for it=1:N
    if(noise(it)==0)
        fecg=MECGcancellation(up_original(it,:),battiti_materni*4*8, Apost{it,:});
    else
        fecg=up_original(it,:);
        struct_template(it,1)={[]};
        struct_annotazioni(it,1)={[]};
    end

    FECG(it,1)={fecg};
end
if(sum(noise)==4)
    alarm=1;
end

%% RESAMPLING FECG AND FILTERING MATERNAL P/T WAVES
for tk=1:N
   temp=resample(FECG{tk,:}',fproc,8*fs);
   FECG_down(tk,:)=temp';
   Hd = filtro_fir_2_6_250b;
   Num=Hd.Numerator;
   y(tk,:)=filtfilt(Num,1,FECG_down(tk,:));
   Hd = filtro_fir_45_50_250;
   Num=Hd.Numerator;
   y(tk,:)=filtfilt(Num,1,y(tk,:));
end

%% FECG ENHANCEMENT (JADE ALGORITHM)
X=y;
B = jadeR(X);
Y=B*X;


%% FETAL QRS DETECTOR
percentuale_soglia=0.6; %percentage of the threshold
intorno_sovrasoglia=3;  %number of peaks overthreshold
battiti=battiti_materni;
RRist=0;
RRist=battiti(2:end)-battiti(1:end-1);
periodicita_materna=round(median(RRist)); %maternal average RR interval
th_periodicity=60;
forget=1/4;
delay=0;

Yjade=Y;
BEATS={};
BEATS_corr={};
score=zeros(4,1);
periodicita=zeros(4,1);
for z=1:size(Yjade,1)
%detection
    uscita(z,:)=algoritmoBfetale(Yjade(z,:)'); %feature signal extraction
    [qrs]=trova_picchi_fetali(uscita(z,:), percentuale_soglia, intorno_sovrasoglia);
    qrs=qrs-9;  
    BEATS(z,1)={qrs};
    if(length(qrs)>0)
%         single-channel pseudo-periodicity corrector
        [occtmp,count_removed,count_added]=periodicity_correction_v2(qrs,length(Yjade(1,:)),th_periodicity,forget, delay,1,1);
        BEATS_corr(z,1)={occtmp};
        score(z,1)=count_removed+1.5*count_added;  %score for choosing criteria
        trustworthy(z,1)=count_removed+2*count_added; %evaluation score
        RRist=occtmp(2:end)-occtmp(1:end-1);
        periodicita(z,1)=round(median(RRist));
     else
        score(z,1)=satura;
    end
end
canale=0;
satura=100000000;
can=1;
trustworthySCORE=[];
while(canale==0)
    [val,ind]=min(score);
    if(periodicita(ind,1)+10<periodicita_materna)
        canale=ind;
        if(trustworthy(ind)<=30)
            trustworthySCORE=3; %trustworthy result
        elseif((trustworthy(ind)>30)&&(trustworthy(ind)<=50))
            trustworthySCORE=2; %reasonably trustworthy result
        elseif(trustworthy(ind)>50)
            trustworthySCORE=1; %not trustworthy result
        end
    else
        score(ind)=satura;
        can=ind;
    end
    if(sum(score)==(4*satura))
        canale=100;
    end
end
if(canale==100)
    picchi_jade=BEATS_corr{can,1};
else
    picchi_jade=BEATS_corr{canale,1};
end
battiti_materni=battiti_materni*4;
FQRS=4*picchi_jade;
if(alarm==1)
    trustworthySCORE=1; %not trustworthy result
end


fetal_QRSAnn_est= round(1000*FQRS'/fs);
QT_Interval = 0;
end





function [FilteredECG, original_d] = preprocessing(ECG,F_acq, F_proc)
% ---- preprocess the data ----
% ECG=input signal
% F_acq= frequency of acquisition
% F_proc= frequency of processing

%FilteredECG=filtered signal @F_proc
%original_d=filtered signal @F_acq


%% searching for NaN and replacing by cubic splining
for mk=1:size(ECG,1)
    seg=ECG(mk,:);
    l=isnan(seg);  % find NaN
    z=find(l==1);  
    z=[z,0];
    c=1;

    while c<length(z)
        if(z(c)>0)
            start=z(c);
            stop=z(c);
            if(z(c)==length(seg))
            else
                while(z(c+1)-z(c)==1)
                    c=c+1;
                    stop=z(c);
                end
            end
        end
        c=c+1;
        delta=stop-start;
        if(delta==0) %only one sample
            delta=3;
        end
        if(((start-delta)>0)&&((stop+delta)<length(seg)+1))
            % spline interpolation
            a=[start-delta:start-1, stop+1:stop+delta];
        elseif((start-delta)<1)
            %spline from beginning
            if(start>1)
                a=[1:start-1, stop+1:stop+delta];
            else
                a=[start,stop+1: stop + delta];
            end
        elseif((stop+delta)>length(seg))
            %spline to end
            if(stop<length(seg))
                a=[start-delta:start-1, stop+1:length(seg)];
            else
                a=[start-delta:start-1, stop];
            end
        end
        b=seg(a);
        d=(start:stop);
        tt=spline(a,b,d);
        seg(start:stop)=tt;
    end
    ECG(mk,:)=seg;
   
end



%% find and correct outliers
F_elab=F_proc;
ECG=ECG-mean(ECG,2)*ones(1,length(ECG));
for z=1:size(ECG,1)
    data(z,:)=DERIVATORE(ECG(z,:),1); %derivative filter to find outliers
end
s=zeros(1,size(data,1));
for z=1:size(data,1)
    s(z)=std(data(z,:));
end
a=10;
soglie=a*s;
for l=1:size(data,1)
    ECG(l,:)=taglia_outlier2(ECG(l,:),data(l,:),soglie(l)); %remove outliers
end


%%  LOW PASS FILTERING
Hd = filtro_fir_46_50_1000;
Num=Hd.Numerator;
for l=1:size(ECG,1)
    ECG(l,:)=filtfilt(Num,1,ECG(l,:));
end

%% HIGH PASS FILTERING
Hd = filtro_fir_1_2_1000;
Num=Hd.Numerator;
for l=1:size(ECG,1)
    ECG(l,:)=filtfilt(Num,1,ECG(l,:));
end
original_d= ECG;


%% DOWNSAMPLING
for l=1:size(ECG,1)
    down(:,l)=resample(ECG(l,:)',F_elab,F_acq);
end
FilteredECG=down';

end

function [uscita]=taglia_outlier2(original,ingresso,soglia) 
%function for the outliers removal 
%original= input signal
%ingresso= derivative of the signal
%soglia = threshold
%uscita = output without outliers

t=find(abs(ingresso)>soglia);
uscita=original;
if(isempty(t))
else
    j=t;
    for v=(length(t)):-1:2
        if(abs(t(v)-t(v-1))==1)
            j(v)=0;
        end
    end
    for z=1:length(j)
        indice=j(z);
        if(indice==0)
        else
            if((indice-5)<1)
                delta=original(1:(indice+10) );
                th=abs(median(delta));
                fb=indice+10;
                while(abs(original(fb)-original(fb-1))<3*th)
                    fb=fb-1; % right end
                    if(fb==1)
                        fb=indice+10;
                        break;
                    end
                end
                estremo_dx=fb;
                uscita(1,1:estremo_dx)=original(estremo_dx);
            elseif((indice+10)>length(original)-1)
                delta=original((indice-5):end );
                th=abs(median(delta));
                fb=indice-5;
                while(abs(original(fb)-original(fb+1))<3*th)
                    fb=fb+1; % left end
                    if(fb==length(original))
                        fb=indice-5;
                        break;
                    end
                end
                estremo_sx=fb;
                uscita(1,estremo_sx:end)=original(estremo_sx);
            else
                delta=original((indice-5):(indice+10) );
                th=abs(median(delta));
                fb=indice-5;
                while(abs(original(fb)-original(fb+1))<3*th)
                    fb=fb+1; % left end
                    if(fb>=indice+10)
                        fb=indice+10;
                        break;
                    end
                end
                estremo_sx=fb;

                fb=indice+10;
                while(abs(original(fb)-original(fb-1))<3*th)
                    fb=fb-1; % right end
                    if(fb<=indice-5)
                        fb=indice-5;
                        break;
                    end
                end
                estremo_dx=fb;
                c=(estremo_dx - estremo_sx)-1;
                if(c>1)
                    a=[(estremo_sx-c-1):estremo_sx, estremo_dx: (estremo_dx+c+1)];
                    b=original(a);
                    d=(estremo_sx+1 : estremo_dx - 1);
                    tt=spline(a,b,d);
                    uscita(estremo_sx+1 : estremo_dx - 1)=tt;
                elseif c==1
                    a=[(estremo_sx-1):estremo_sx, estremo_dx: (estremo_dx+1)];
                    b=original(a);
                    d=estremo_sx+1;
                    tt=spline(a,b,d);
                    uscita(estremo_sx+1 : estremo_dx - 1)=tt;
                end
            end
        end
    end
end
end

function y=DERIVATORE(x,parametro)
%derivative filtering
% x=input signal
% parametro= parameter for choosing the derivative filter
    switch(parametro)
        case 0
            b=(1/2)*[1 -1];
            a=1;
            y=filter(b,a,x);
        case 1
            b=(1.99/2)*[1 -1];
            a=[1 -0.99];
            y=filter(b,a,x);
    end
end

function [pulito]=MECGcancellation(segnale,mqrs,template)
%function for the maternal QRS complex subtraction @8kHz
%segnale= input signal
%mqrs= maternal QRS annotations
%template= maternal template
%pulito= output signal after subtraction

    [rt,ct]=size(template);
    dim=(ct);
    for tm=1:rt
        temp_sottr(tm,:)=template(tm,:).*(tukeywin(dim, 0.2))'; %multiplication with the Tukey window
    end
    pulito=segnale;
    delta_stop=0;
    for lt=1:length(mqrs)
        inds=mqrs(lt);
        if((inds+dim)>length(segnale))
            ui=length(segnale);
            delta_stop=inds+dim-ui;
            tempn=[segnale(inds-dim:end), zeros(1,delta_stop)];
            inizio=dim-1;
        elseif((inds-dim)<1)
            tempn=[zeros(1,-inds+dim+1) segnale(1:inds+dim)];
            inizio=dim-1;
        else
            tempn=segnale(inds-dim:inds+dim);
            inizio=dim-1;
        end
        for tm=1:rt
           r_pc(tm,:)=pearsoncoeff(tempn,temp_sottr(tm,:)); %choose the template with the highest correlation
           [mt, it]=max(r_pc(tm,:));
           mar(tm)=mt;
           inr(tm)=it;
        end
        [ma,in]=max(mar);
        start=inds-inizio-2+inr(in);
        delta_start=0;
        if(start<1)
             start=1;
            delta_start=-inds+dim;
        end
        if(delta_stop>1)
            delta_stop=start+dim-length(segnale)-1;
        end
        if(delta_stop<0)
            delta_stop=0;
        end
        if(delta_stop<0)
            delta_stop=0;
        end

        deb1=segnale(start:start+dim-1-delta_stop-delta_start);
        segnmax=max((segnale(start:start+dim-1-delta_stop-delta_start)));
        tempmax=max((temp_sottr(in,delta_start+1:end-delta_stop)));
        %compute the gain
        if(tempmax~=0)
            Gpos=segnmax/tempmax;
        else
            Gpos=1;
        end
        segnmin=min((segnale(start:start+dim-1-delta_stop-delta_start)));
        tempmin=min((temp_sottr(in,delta_start+1:end-delta_stop)));
        if(tempmin~=0)
            Gneg=segnmin/tempmin;
        else
            Gneg=1;
        end
        deb2=0;
        for kl=1:length(deb1)
            if(temp_sottr(in,kl)>0)
                deb2(kl)=temp_sottr(in,delta_start+kl)*Gpos;
            else
                deb2(kl)=temp_sottr(in,delta_start+kl)*Gneg;
            end
        end
        pulito(start:start+dim-1-delta_start-delta_stop)=segnale(start:start+dim-1-delta_start-delta_stop)-(deb2(1:end));
    end
end

function [Apost,occorrenze_finali]=PeakDetection(mann, LEN, Thcross,Thc,Thfusione, original_d)
%function for the extraction of the maternal QRS complexes
%mann= maternal QRS complexes annotations @250Hz
%LEN= length of the templates @8kHz
%Thcross= Threshold for computing cross-correlation between final template
%         and input signal
%Thc= Threshold for template creation
%Thfusione= Threshold for templates fusion 
% original_d= input signal @8kHz

% Apost= output template matrix
% occorrenze_finali= template occurrences

mid = LEN;
occorrenze_finali=[];
occ=0;
mid_mezzi = LEN/2;
NumTempl=6; %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% starting variable creation
NTM = 10; % max number of templates
Nt = 0; % current number of template
A = zeros(NTM,LEN); % template matrix
Templ_overwritten = 0;
Ttot = zeros(NTM,1); % total occurrences
tmp = zeros(1,LEN); % temporary buffer
cc = zeros(NTM,LEN);% cross-correlation matrix

matrice_template=zeros(1,LEN);
conta_template=1;
BUFF =original_d;

materni=4*mann*8;  %fetal peaks @8kHz
indice_precedente=0;
QRSs=materni;
if(length(QRSs)>5)
    cb=1;
while(QRSs(cb)<2000)
    cb=cb+1;
end
for idx_QRSs=cb:length(QRSs)-1
    if QRSs(idx_QRSs)-LEN/2<1
        Kin=1;
    else
        Kin=QRSs(idx_QRSs)-LEN/2;
    end
    if QRSs(idx_QRSs)+LEN/2-1>length(BUFF)
        Kfn=length(BUFF);
    else
        Kfn=QRSs(idx_QRSs)+LEN/2-1;
    end
    if(Kin==1)
        Kfn=LEN;
    end
    if(Kfn==length(BUFF));
        Kin=length(BUFF)-LEN+1;
    end
    
    prova1=0;
    prova2=1000000;
    for tb=Kin+round(mid/4):Kfn-round(mid/4)
        if(BUFF(tb)>prova1)
            prova1=BUFF(tb);
            m_pos=tb;
        end
        if(BUFF(tb)<prova2)
            prova2=BUFF(tb);
            m_neg=tb;
        end
    end
   prova2=abs(prova2);

   if(prova2>1.4*prova1)
       m=m_neg;
   else
       m=m_pos;
   end

    tmp = zeros(size(tmp));
    ampt=floor((4.2/8)*mid);
    sts=ampt-floor(mid/2);
    if((m-ampt+2>0)&&(m+ampt+1<=length(BUFF)))        
        tmp(1:2*ampt)=BUFF(m-ampt+2:m+ampt+1);
    end
    invld=0;
    if(1.2*max(abs(tmp(ampt-0.1*mid:ampt+0.1*mid)))<(max(abs(tmp))))
        %%not valid template
        invld=1;
    end
    if(invld==0)
    
        maxcorr=zeros(NTM,1);
        indexmaxcorr=zeros(NTM,1);
        if Nt == 0; % no template before
            A(1,:)=tmp(sts:sts+mid-1);
            indice_precedente=m;
            matrice_template(conta_template,:)=A(1,:);
            conta_template=conta_template+1;
            Ttot(1,1)=1;
            Nt = 1;
        else
        %there is at least 1 template, do cross-correlation
            for k=1:Nt
                cctemp = pearsoncoeff(tmp,A(k,:));
                cc(k,1:length(cctemp)) = cctemp; 
                [maxcorr(k),indexmaxcorr(k)]=max(cctemp);
            end
            [mm,im]= max(maxcorr);
            if mm>Thc
                distanza_template=max(A(im,:))+abs(min(A(im,:)));
                distanza_buffer=max(tmp(indexmaxcorr(im):indexmaxcorr(im)+LEN-1))+abs(min(tmp(indexmaxcorr(im):indexmaxcorr(im)+LEN-1)));
                rapporto_amp=abs((distanza_template-distanza_buffer)/(distanza_template+distanza_buffer));
               if(rapporto_amp>0.5)
                   mm=0;
               end
            end
            if mm < Thc
                if Nt < NTM % number of template lesser of the maximum
                    if(abs(m-indice_precedente)>40)
                        A(Nt+1,:)=tmp(sts:sts+LEN-1);
                        indice_precedente=m;
                        matrice_template(conta_template,:)=A(Nt+1,:);
                        conta_template=conta_template+1;
                        Ttot(Nt+1,1)=1;
                        Nt=Nt+1;
                    end
                else % if the number of classes is higher than the maximum, 
                     %  remove the template with the minimum number of occurrences
                    if(abs(m-indice_precedente)>40)
                        [mmin, mminidx] = min(Ttot);

                        Templ_overwritten = Templ_overwritten + 1;
                        A(mminidx,:)=tmp(sts:sts+LEN-1);
                        matrice_template(conta_template,:)=A(mminidx,:);
                        conta_template=conta_template+1;
                        indice_precedente=m;
                        Ttot(mminidx,1)=1;
                    end
                end
            else
                if(abs(m-ampt+2+indexmaxcorr(im)+round(mid/2)-indice_precedente)>40)
                    estrattoy = tmp(indexmaxcorr(im):indexmaxcorr(im)+LEN-1);                    
                    indice_precedente=m-ampt+2+indexmaxcorr(im)+round(mid/2);
                    matrice_template(conta_template,:)=estrattoy;
                    conta_template=conta_template+1;
            
                    A(im,:) = synchronizedAVG(A(im,:),estrattoy,Ttot(im,1));
                    Ttot(im,1) = Ttot(im,1)+1;

                end
            end
        end
    end
end

indexA = 1;
% template fusion
while indexA < Nt
    tmp(sts:sts+LEN-1) = A(indexA,:);
    maxcorr=zeros(NTM,1);
    indexmaxcorr=zeros(NTM,1);
    for k=indexA+1:Nt
        cctemp = pearsoncoeff(tmp,A(k,:));
        cc(k,1:length(cctemp)) = cctemp;
        [maxcorr(k),indexmaxcorr(k)]=max(cctemp);
    end
    [mm,im]= max(maxcorr);
    if mm > Thfusione
        estrattoy = tmp(indexmaxcorr(im):indexmaxcorr(im)+LEN-1);
        A(indexA,:) = synchronizedWAVG(estrattoy,A(im,:),Ttot(indexA,1),Ttot(im,1));
        Ttot(indexA,1) = Ttot(indexA,1)+Ttot(im,1);
        A(im,:)=A(Nt,:);
        Ttot(im,1)=Ttot(Nt,1);
        A(Nt,:)=0;
        Ttot(Nt,1)=0;
        Nt=Nt-1;
        indexA=1;
    else
        indexA=indexA+1;
    end
end
Apost = zeros(NumTempl,LEN);

Atemp=A;
Ttottemp = Ttot;
Ttotpost = zeros(NumTempl,1);
% reduce the number of template
for i = 1 : NumTempl
    [m,idx] = max(Ttottemp);
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
    Ttotpost(i) = m;
    Apost(i,:)=Atemp(idx,:);
    Ttottemp(idx) = [];
    Atemp(idx,:) = [];
end
indd=NumTempl;
for i = 1 : indd
   if(Ttotpost(i)<20)
       Ttotpost(i)=0;
       Apost(i,:)=zeros(1,length(Apost(i,:)));
       NumTempl=NumTempl-1;
   end
end
Apost=Apost(1:NumTempl,:);
Ttotpost=Ttotpost(1:NumTempl);
clear Atemp
clear Ttottemp

BUFF=original_d;
for k=1:NumTempl  
    cctemp=[];
    [mA,iA]=max(Apost(k,:));
    cctemp = pearsoncoeff(BUFF,Apost(k,:));
    cctemp=cctemp.*(abs(cctemp) > Thcross); %hard thresholding of cross-correlation
    j=1;
    h=1;
    while j<length(cctemp)
        if cctemp(j)>0
            start_m=j;
            while cctemp(j)>0 && j<length(cctemp)
                end_m=j;
                j = j+1;
            end
            [mp,ip]=max(cctemp(start_m:end_m));
            occ(k,h)=ip+start_m-1;
            occorrenze_finali(k,1)=h;
            h=h+1;
        end
        j=j+1;
    end
end
else
    Apost=[];
    occorrenze_finali=[];
end


end

function [r] = pearsoncoeff(x,y)
%function for the Pearson correlation coefficient computation
sx = size(x);
sy = size(y);
if min(size(x)) > 1
    error('It is not possible to use this function on matrix')
    return
end
if min(size(y)) > 1
    error('It is not possible to use this function on matrix')
    return
end
if sx(1) > sx(2)
    x=x';
end
if sy(1) > sy(2)
    y=y';
end
if length(x) < length(y) 
    tmp=y;
    y=x;
    x=tmp;
end
ly =length(y);
lr = length(x)-ly+1;
r = zeros(1,lr);
stdy = std(y);
meany = mean(y);
yc = y - meany;
for i=1:lr
   stdx = std(x(i:i+length(y)-1));
   meanx = mean(x(i:i+length(y)-1));
   xc = x(i:i+length(y)-1) - meanx;
   num = sum((1/(ly-1))*xc.*yc);
   r(i)=num/(stdy*stdx);
end
end

function u = synchronizedAVG(oldu,y,n)
%function for the computation of the synchronized average in template
%creation
loldu = length(oldu);
ly = length(y);
if loldu ~= ly
    error('Arrays must have the same length');
end
if (min(size(oldu)) ~= 1) || (min(size(y)) ~= 1)
    error('Only arrays, not matrices!');
end
u=((oldu*n)+y)/(n+1);
end

function u = synchronizedWAVG(firstsig,secondsig,wfirst,wsecond)
%function for the computation of the synchronized average in template
%fusion
N=wfirst+wsecond;
u=(firstsig*wfirst/N)+(secondsig*wsecond/N);
end

function [uscita]=PanTompkinsAlgorithm(segnale_in)
%PanTompkins filters 

b9_LP = [1 0 0 0 0 0 -2 0 0 0 0 0 1];
a9_LP = [1 -2 1];
g=36;
b9_LP = (1/g)*b9_LP;

b9_HP = (1/32)*[-1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 32 -32 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 ];
a9_HP = [1 -1];

b9_diff2 = (1/10)*[2 1 0 -1 -2];

b9_integr = (1/37)*ones(37,1);

OUT9_1= filter(b9_LP,a9_LP,segnale_in);

OUT9_2= filter(b9_HP,a9_HP,OUT9_1);

OUT9_3= filter(b9_diff2,1,OUT9_2);
OUT9_4= (OUT9_3).^2;
uscita= filter(b9_integr,1,OUT9_4);
end

function [qrs]=trova_picchi_pan_tompkins(ys, perc_soglia, intorno)
% QRS detection of the Pan Tompkins function output @250Hz
%ys= output of the PanTompkinsAlgorithm function
%perc_soglia= percentage threshold of amplitude
% intorno= number of samples overthreshold
% qrs=identified peaks

nu=floor(length(ys)/250);

soglia=zeros(1,length(ys));
for t=1:nu
    buffer=ys((t-1)*250 +1 : ((t)*250));
    buffer=sort(buffer);
    buffer=buffer(1:length(buffer)-5);  
    soglia((t-1)*250 +1 : t*250) = perc_soglia* max(buffer); 
end

j = 1;
qrs = zeros(size(ys)); 
for i=2:length(ys)-1
    if((ys(i)>soglia(i))&&(ys(i+1)<soglia(i+1)))
        qrs(j)=i;
        zi=1;
        while(ys(i-zi)>soglia(i-zi))
            qrs(j)=i-floor(zi/2);  %centre the peak
            if((i-zi)<2)
                break;
            end
            zi=zi+1;
        end
        if(zi-1>intorno)
            j=j+1;
        end
    end
end

qrs(j:end) = []; 

qrs=qrs-42;
tu=find(qrs<1);
if(length(tu)>0)
    qrs(tu)=[];
end
qrs=unique(qrs);
end

function[picchi]=analisi_periodicita_picchi2(peaks,soglia)
%multichannel pseudo-periodicity correction and channel selection
% peaks=QRS cell array (each row contains QRS annotations of the corresponding channel)
% soglia= pseudo-periodicity threshold
% picchi= final single-channel QRS annotations

buffer_per=zeros( length(peaks),1);
soglia_noise=10;
noise=zeros( length(peaks),1);
period={};
buff_lqrs=zeros( length(peaks),1);
for i=1: length(peaks)
    battiti=peaks{i,1};
    buff_lqrs(i)=length(battiti);
    RRist=0;
    RRist=battiti(2:end)-battiti(1:end-1);
    RRm=round(median(RRist));  %searching for outliers
    delta=abs(RRist-RRm);
    occ=ones(size(delta));
    occ(delta<=soglia)=0;
    if(length(battiti)==0)
        occ=ones(1,1000);
    end
    period(i,1)={occ};
    
    buffer_per(i,1)=sum(occ);
end
%searching for the best channel
[minimo, ind_minimo]=min(buffer_per);
if(minimo==0)
    picchi=peaks{ind_minimo,1};
    pt=find(buffer_per==0);
    kv=buff_lqrs(pt);
    kt=unique(kv);
    if(length(kt)==1) %compute the final QRS annotation as the average of the
                      %position found in each channel without outliers and
                      %with the same number of peaks
        matr=[];
        for t=1:length(pt)
            matr(t,:)=peaks{pt(t),1};
        end
        picchi=round(mean(matr,1));
    elseif(length(pt)>2) %compute the final QRS annotation as the average of the
                         %position found in each channel choosing the
                         %number of peaks occurring in more channels
        pres=zeros(1,length(kt));
       for z=1:length(kt)
           to=0;
           to=find(kv==kt(z));
           pres(z)=length(to);
       end
       [mass,indmass]=max(pres);
       matr=[];
       V=1;
       for t=1:length(pt)
           if(kv(t)==kt(indmass))
                matr(V,:)=peaks{pt(t),1};
                V=V+1;
           end
       end
       picchi=round(mean(matr,1));
    end
    for t=1: length(peaks)
        if(buffer_per(t,1)>=soglia_noise)
            noise(t)=1; %noise channel, stop analysis
        end
    end
elseif(minimo<soglia_noise)
    % point-by-point correction of pseudo-periodicity outliers of the best channel using
    % the annotations of other channels which periodicity is under the noise threshold
    val_canale_confronto=soglia_noise;
    canale_confronto=ind_minimo;
    for t=1: length(peaks)
        if(buffer_per(t,1)>=soglia_noise)
            noise(t)=1; %noise channel, stop analysis
        end
  
    end
    [Y,vettore_confronto] = sort(buffer_per);
    picchi=peaks{ind_minimo,1};
    picchi_precedenti=picchi;
    for t=2: length(peaks)
        if(noise(vettore_confronto(t))==0)
            canale_confronto=vettore_confronto(t);
            %searching for errors and replacing them with annotation from
            %other channels
            
            pic_confronto=peaks{canale_confronto,1};
            indici=find(period{ind_minimo,1}==1);
            indici_def=indici;
            for u=1:length(indici)-1
                if(abs(indici(u)-indici(u+1))==1)
                    indici_def(u+1)=0;
                    tipo_ind(u)=1;
                    tipo_ind(u+1)=1;
                end
            end
            temp= indici_def==0;

            indici(temp)=[];
            for z=1:length(indici)
                if(indici(z)<length(picchi)-2)
                    start=picchi(indici(z));
                    stop=picchi(indici(z)+2);
                    [min_start,ind_start]=min(abs(start-pic_confronto));
                    [min_stop,ind_stop]=min(abs(stop-pic_confronto));
                    picchi(indici(z):indici(z)+2)=[];
                
                    picchi=[picchi, pic_confronto(ind_start:ind_stop)];
                    picchi=unique(picchi);
                    picchi=sort(picchi);
                    RRist=0;
                    RRist=picchi(2:end)-picchi(1:end-1);
                    RRm=round(median(RRist));
                    delta=abs(RRist-RRm);
                    occ=ones(size(delta));
                    occ(delta<=soglia)=0;
                    val=sum(occ);
                    if(val>=minimo) %if this substitution do not improve pseudo-periodicity
                        picchi=picchi_precedenti; %do not correct annotations
                    else %if this substitution improve pseudo-periodicity
                        minimo=val; %correct annotations
                        picchi_precedenti=picchi;
                    end
                end
            end
        end
    end
else
    %if all the channels are too noisy choose the best one
    picchi=peaks{ind_minimo,1};
end
end

function[occtmp,count_removed,count_added]=periodicity_correction_v2(occ,stop_cond,thRR,gamma,starting_delay,idx_preval,len_longest)
% single-channel pseudo-periodicity corrector
% occ= occurrences to correct
% stop_cond= stop condition (e.g., end of the signal)
% thRR= pseudo-periodicity threshold
% gamma= pseudo-periodicity forgetting factor to update RR
% starting_delay= delay before starting the analysis

%occtmp= occurrences after correction
%count_removed=number of peaks removed
%count_added=number of peaks added
    occtmp=0;
    occchk=0;
    RRm=0;
    count_removed=0;
    count_added=0;
    noise=0;
    if size(occ,1)>size(occ,2)
    occ=occ';
    end
    occtmp=occ(1,occ>0); %remove zeros
    RRist=occtmp(2:end)-occtmp(1:end-1); %find RR intervals
    RRm=round(median(RRist)); %median RR starting value 
    delta=abs(RRist-RRm); %evaluate distance 
    occchk=zeros(size(delta)); %find outliers
    occchk(delta<=thRR)=1; 

    start = idx_preval;

    %begin from start
    if noise == 0
    count_removed = 0;
    count_added = 0;
    i=start;
    if len_longest >= 5
        RRm = occtmp(i+1)-occtmp(i);
    end
    while i<length(occtmp)-2 

        if occchk(i) ~= 0 
            nextR = occtmp(i) + RRm; %forecast next peaks

            j=i+1;
            best_occ = [];
            best_idx = [];
            while abs(occtmp(j)-nextR) <=  thRR
                if isempty(best_occ) 
                    best_occ = abs(occtmp(j)-nextR);
                    best_idx = j;
                else 
                    if abs(occtmp(j)-nextR) < best_occ 
                        best_occ = abs(occtmp(j)-nextR); 
                        best_idx = j; %find the best peak in a tolerance interval 
                    end
                end
                j=j+1;
                if j>length(occtmp)
                    break
                end
            end
            %remove all the peaks around the best
            for aux=i+1:j-1
                if aux ~= best_idx
                    occtmp(aux)=60000; 
                    occchk(aux)=60000; 
                    count_removed = count_removed+1; %index of removed peaks
                end
            end
            occtmp(occtmp==60000)=[]; 
            occchk(occchk==60000)=[]; 
            if(i>length(occtmp)-2)
                break;
            end
            if j-1>=i+2 %only one peak found in the tolerance interval
                if abs(occtmp(i+2)-occtmp(i+1)-RRm) <= thRR
                    occchk(i+1)=1;
                else
                    occchk(i+1)=0;
                end
            end

            %updating autoregressive model
            RRm=round(RRm*(1-gamma)+(occtmp(i+1)-occtmp(i))*gamma);
        else %if the distance exceeds the tolerance interval
            
            nextR = occtmp(i) + RRm; %predict next occurrence
            j=i+1; 
            while occtmp(j) < nextR - thRR 
                occtmp(j)=60000;
                occchk(j)=60000; 
                count_removed = count_removed+1; %index of the removed peaks
                j=j+1; 
                if j>length(occchk)
                    break
                end
            end
            occtmp(occtmp==60000)=[]; 
            occchk(occchk==60000)=[]; 
            if abs(occtmp(i+1)-occtmp(i)-RRm) <= thRR
      
                occchk(i)=2;
            else
                occchk(i)=0;
            end

            nextR = occtmp(i) +RRm;

            %working around the predicted occurrence
            j=i+1;
            best_occ = [];
            best_idx = [];
            while abs(occtmp(j)-nextR) <=  thRR
                if isempty(best_occ) 
                    best_occ = abs(occtmp(j)-nextR);
                    best_idx = j;
                else 
                    if abs(occtmp(j)-nextR) < best_occ 
                        best_occ = abs(occtmp(j)-nextR); 
                        best_idx = j; 
                    end
                end
                j=j+1;
                if j>length(occtmp)
                    break
                end
            end
            if isempty(best_occ) 
                %adding the predicted occurrence
                occtmp=[occtmp(1:i),nextR,occtmp(i+1:end)];
                occchk=[occchk(1:i),3,occchk(i+1:end)]; 
                count_added = count_added+1;
                if abs(occtmp(i+2)-occtmp(i+1)-RRm) <= thRR
                    occchk(i+1)=3;
                else
                    occchk(i+1)=0;
                end
                occchk(i)=3;
            else 
                for aux=i+1:j-1
                    if aux ~= best_idx
                        occtmp(aux)=60000; 
                        occchk(aux)=60000; 
                        count_removed = count_removed+1; 
                    end
                end
                occtmp(occtmp==60000)=[]; 
                occchk(occchk==60000)=[]; 
                if(i>length(occtmp)-2)
                    break;
                end
                if j-1>=i+2 
                    if abs(occtmp(i+2)-occtmp(i+1)-RRm) <= thRR
                        occchk(i+1)=1;
                    else
                        occchk(i+1)=0;
                    end
                end
            end
        end
        i=i+1;
    end
    %if no occurrences have been found up to the end of the signal
    while stop_cond - occtmp(length(occtmp)) > RRm
        nextR = occtmp(length(occtmp)) + RRm;
        occtmp=[occtmp,nextR];
        occchk=[occchk,3]; %add a peak and increment the count_added variable
        count_added = count_added+1; 
    end


    % moving to the beginning
    i=start;
    if len_longest >= 5
        RRm = occtmp(i+1)-occtmp(i);
    end
    while i>3 %up to the beginning
        if occchk(i-1) ~= 0 
            % trying to forecast next peak
            nextR = occtmp(i) - RRm;
            if(nextR<starting_delay)
                break
            end

            %searching for surrounding peaks 
            j=i-1;
            best_occ = [];
            best_idx = [];
            while abs(occtmp(j)-nextR) <=  thRR
                if isempty(best_occ) 
                    best_occ = abs(occtmp(j)-nextR);
                    best_idx = j;
                else %if there are more peaks in the tolerance interval of pseudo-periodicity
                    if abs(occtmp(j)-nextR) < best_occ %choose the best peak in the tolerance interval
                        best_occ = abs(occtmp(j)-nextR);
                        best_idx = j; 
                    end
                end
                j=j-1;
                if j<1
                    break
                end
            end
            %removing all other surrounding peaks
            for aux=i-1:-1:j+1
                if aux ~= best_idx
                    occtmp(aux)=60000; 
                    occchk(aux)=60000; 
                    count_removed = count_removed+1; %counting removed peaks
                end
            end
            occtmp(occtmp==60000)=[]; 
            occchk(occchk==60000)=[]; 
            if j+1<i-1 
                if abs(occtmp(i-1)-occtmp(i-2)-RRm) <= thRR
                    occchk(i-2)=1;
                else
                    occchk(i-2)=0;
                end
            end

            %updating auto-regressive model of RR interval
            RRm=round(RRm*(1-gamma)+(occtmp(i)-occtmp(i-1))*gamma);
        else %if the distance is out of the tolerance interval
            
            %trying to forecast the next occurrence
            nextR = occtmp(i) - RRm;

            j=i-1; %starting from the first occurrence
            while occtmp(j) >= nextR + thRR %remove peaks
                occtmp(j)=60000; 
                occchk(j)=60000; 
                count_removed = count_removed+1; 
                j=j-1; 
                if j<1
                    break
                end
            end
            if abs(occtmp(i)-occtmp(j)-RRm) <= thRR
                occchk(j)=2;
            else
                occchk(j)=0;
            end
            occtmp(occtmp==60000)=[]; 
            occchk(occchk==60000)=[]; 

            nextR = occtmp(i) - RRm;

          
            j=i-1;
            best_occ = [];
            best_idx = [];
            while abs(occtmp(j)-nextR) <=  thRR
                if isempty(best_occ) 
                    best_occ = abs(occtmp(j)-nextR);
                    best_idx = j;
                else 
                    if abs(occtmp(j)-nextR) < best_occ 
                        best_occ = abs(occtmp(j)-nextR); 
                        best_idx = j; 
                    end
                end
                j=j-1;
                if j<1
                    break
                end
            end
            if isempty(best_occ) 
                occtmp=[occtmp(1:i-1),nextR,occtmp(i:end)];
                occchk=[occchk(1:i-1),3,occchk(i:end)]; 
                count_added = count_added+1;
                if abs(occtmp(i)-occtmp(i-1)-RRm) <= thRR

                    occchk(i-1)=3;
                else
                    occchk(i-1)=0;
                end
                i=i+1;
            else 
                for aux=i-1:-1:j+1
                    if aux ~= best_idx
                        occtmp(aux)=60000; 
                        occchk(aux)=60000; 
                        count_removed = count_removed+1; 
                    end
                end
                occtmp(occtmp==60000)=[]; 
                occchk(occchk==60000)=[]; 

                if j+1<i-1
                    i=j+2;
                    if abs(occtmp(i)-occtmp(i-1)-RRm) <= thRR
                        occchk(i-1)=1;
                    else
                        occchk(i-1)=0;
                    end
                end
            end
        end
        i=i-1;
    end
    %if starting_delay is not 0
    while occtmp(1) > RRm
        nextR = occtmp(1) - RRm;
        if(nextR<starting_delay)
            break
        end
        occtmp=[nextR,occtmp];
        occchk=[3,occchk]; 
        count_added = count_added+1;
    end

    end
end

function[segnale]=algoritmoBfetale(segnale_in)
%feature signal extraction @250Hz
%segnale_in= input signal
%segnale= output signal
in=zeros(1,2);
f_derivata_prima=(1/2)*[1 -1];
f_derivata_seconda=(1/4)*[1 0 -2 0 1];
filtro_nuovo=(1/44)*[2 4 8 16 8 4 2];
f_movingaverage=(1/8)*ones(1,8);
M=8;

pfn=zeros(1,7);
ufn=zeros(1,2);
ingr=zeros(1,5);
comblin=zeros(1,8);
buds=zeros(1,2);

segnale=zeros(1,length(segnale_in));        

buffer_der=zeros(1,length(segnale_in)); 
buffer_filtronuovo=zeros(1,length(segnale_in));
buffer_dersec=zeros(1,length(segnale_in));
buffer_comblin=zeros(1,length(segnale_in));

for i_global=1:length(segnale_in)
    newsample=segnale_in(i_global);
    in(1,2)=in(1,1);
    in(1,1)=newsample;
    temp=f_derivata_prima(1)*in(1,1)+f_derivata_prima(2)*in(1,2);
    temp=abs(temp);
    buffer_der(i_global)=temp;
    for i_pfn=7:-1:2
        pfn(1,i_pfn)=pfn(1,(i_pfn-1));
    end
    pfn(1,1)=temp;
    temp=filtro_nuovo(1)*pfn(1,1)+filtro_nuovo(2)*pfn(1,2)+filtro_nuovo(3)*pfn(1,3)+filtro_nuovo(4)*pfn(1,4)+filtro_nuovo(5)*pfn(1,5)+filtro_nuovo(6)*pfn(1,6)+filtro_nuovo(7)*pfn(1,7);
    buffer_filtronuovo(i_global)=temp;
    
    ufn(1,2)=ufn(1,1);
    ufn(1,1)=temp;
    
    temp1=ufn(1,1)*ufn(1,2);
    buffer_mobd(i_global)=temp1;
    
    for i_in=5:-1:2
        ingr(1,i_in)=ingr(1,(i_in-1));
    end
    ingr(1,1)=newsample;
    
    temp2=f_derivata_seconda(1)*ingr(1,1)+f_derivata_seconda(2)*ingr(1,2)+f_derivata_seconda(3)*ingr(1,3)+f_derivata_seconda(4)*ingr(1,4)+f_derivata_seconda(5)*ingr(1,5);
    temp2=abs(temp2);
    
    buffer_dersec(i_global)=temp2;
    
    buds(1,2)=buds(1,1);
    buds(1,1)=temp2;
    
    temp=((1)*(temp1))+ ((0.5)*(buds(1,2)));
    buffer_comblin(i_global)=temp;
    
    for i_cl=8:-1:2
        comblin(1,i_cl)=comblin(1,(i_cl-1));
    end
    comblin(1,1)=temp;
    
    temp=f_movingaverage(1)*comblin(1,1)+f_movingaverage(2)*comblin(1,2)+f_movingaverage(3)*comblin(1,3)+f_movingaverage(4)*comblin(1,4)+f_movingaverage(5)*comblin(1,5)+f_movingaverage(6)*comblin(1,6)+f_movingaverage(7)*comblin(1,7)+f_movingaverage(8)*comblin(1,8);   
   
    segnale(i_global)=temp;
end
b_movingaverage = (1/M)*ones(1,M);
segnale = filter(b_movingaverage,1,buffer_comblin);        
end

function [qrs]=trova_picchi_fetali(ys, perc_soglia,intorno)
%identification of peaks after feature signals extraction @250Hz
% ys=feature signal
% perc_soglia= amplitude percentage threshold
% intorno = number of samples overthreshold
% qrs= identified peaks
nu=floor(length(ys)/250);
        soglia=zeros(1,length(ys));
        for t=1:nu
            buffer=ys((t-1)*250 +1 : ((t)*250));
            buffer=sort(buffer);
            buffer=buffer(1:length(buffer)-10);  
            soglia((t-1)*250 +1 : t*250) = perc_soglia* max(buffer); %computing threshold
        end

        j = 1;
        qrs = zeros(size(ys)); 
        
            for i=2:length(ys)-1
                    if((ys(i)>soglia(i))&&(ys(i+1)<soglia(i+1)))
                        picco=ys(i);
                        qrs(j)=i;
                        zi=1;
                        while(ys(i-zi)>soglia(i-zi))
                           if((ys(i-zi)>picco))
                               qrs(j)=i-zi;
                               picco=ys(i-zi);
                           end
                           if((i-zi)<2)
                               break;
                           end
                           zi=zi+1;
                        end
                        if(zi-1>intorno)
                            j=j+1;
                        end
                    end
             end
                       
            qrs(j:end) = []; 
            tu=find(qrs<1);
            if(length(tu)>0)
                qrs(tu)=[];
            end
            qrs=unique(qrs);
end

function B =  jadeR(X,m)
%   B = jadeR(X, m) is an m*n matrix such that Y=B*X are separated sources
%    extracted from the n*T data matrix X.
%   If m is omitted,  B=jadeR(X)  is a square n*n matrix (as many sources as sensors)
%
% Blind separation of real signals with JADE.  Version 1.9.   August 2013
%
% Usage: 
%   * If X is an nxT data matrix (n sensors, T samples) then
%     B=jadeR(X) is a nxn separating matrix such that S=B*X is an nxT
%     matrix of estimated source signals.
%   * If B=jadeR(X,m), then B has size mxn so that only m sources are
%     extracted.  This is done by restricting the operation of jadeR
%     to the m first principal components. 
%   * Also, the rows of B are ordered such that the columns of pinv(B)
%     are in order of decreasing norm; this has the effect that the
%     `most energetically significant' components appear first in the
%     rows of S=B*X.
%
% Quick notes (more at the end of this file)
%
%  o this code is for REAL-valued signals.  An implementation of JADE
%    for both real and complex signals is also available from
%    http://perso.telecom-paristech.fr/~cardoso/guidesepsou.html
%
%  o This algorithm differs from the first released implementations of
%    JADE in that it has been optimized to deal more efficiently
%    1) with real signals (as opposed to complex)
%    2) with the case when the ICA model does not necessarily hold.
%
%  o There is a practical limit to the number of independent
%    components that can be extracted with this implementation.  Note
%    that the first step of JADE amounts to a PCA with dimensionality
%    reduction from n to m (which defaults to n).  In practice m
%    cannot be `very large' (more than 40, 50, 60... depending on
%    available memory and CPU time)
%
%  o See more notes, references and revision history at the end of
%    this file and more stuff on the WEB
%    http://perso.telecom-paristech.fr/~cardoso/guidesepsou.html
%
%  o This code is supposed to do a good job!  Please report any
%    problem to cardoso@sig.enst.fr


% Copyright (c) 2013, Jean-Francois Cardoso
% All rights reserved.
%
%
% BSD-like license.
% Redistribution and use in source and binary forms, with or without modification, 
% are permitted provided that the following conditions are met:
%
% Redistributions of source code must retain the above copyright notice, 
% this list of conditions and the following disclaimer.
%
% Redistributions in binary form must reproduce the above copyright notice,
% this list of conditions and the following disclaimer in the documentation 
% and/or other materials provided with the distribution.
%
%
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS 
% OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
% AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER 
% OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
% DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
% DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
% IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
% OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


verbose	= 1 ;	% Set to 0 for quiet operation

% Finding the number of sources
[n,T]	= size(X);
if nargin==1, m=n ; end; 	% Number of sources defaults to # of sensors
% if m>n ,    fprintf('jade -> Do not ask more sources than sensors here!!!\n'), return,end
% if verbose, fprintf('jade -> Looking for %d sources\n',m); end ;


% to do: add a warning about complex signals

% Mean removal
%=============
% if verbose, fprintf('jade -> Removing the mean value\n'); end 
X	= X - mean(X')' * ones(1,T);


%%% whitening & projection onto signal subspace
%   ===========================================
% if verbose, fprintf('jade -> Whitening the data\n'); end

[U,D]     = eig((X*X')/T) ; %% An eigen basis for the sample covariance matrix
[Ds,k]    = sort(diag(D)) ; %% Sort by increasing variance
PCs       = n:-1:n-m+1    ; %% The m most significant princip. comp. by decreasing variance

%% --- PCA  ----------------------------------------------------------
B         = U(:,k(PCs))'    ; % At this stage, B does the PCA on m components

%% --- Scaling  ------------------------------------------------------
scales    = sqrt(Ds(PCs)) ; % The scales of the principal components .
B         = diag(1./scales)*B  ; % Now, B does PCA followed by a rescaling = sphering


%% --- Sphering ------------------------------------------------------
X         = B*X;  %% We have done the easy part: B is a whitening matrix and X is white.

clear U D Ds k PCs scales ;

%%% NOTE: At this stage, X is a PCA analysis in m components of the real data, except that
%%% all its entries now have unit variance.  Any further rotation of X will preserve the
%%% property that X is a vector of uncorrelated components.  It remains to find the
%%% rotation matrix such that the entries of X are not only uncorrelated but also `as
%%% independent as possible'.  This independence is measured by correlations of order
%%% higher than 2.  We have defined such a measure of independence which
%%%   1) is a reasonable approximation of the mutual information
%%%   2) can be optimized by a `fast algorithm'
%%% This measure of independence also corresponds to the `diagonality' of a set of
%%% cumulant matrices.  The code below finds the `missing rotation ' as the matrix which
%%% best diagonalizes a particular set of cumulant matrices.

 
%%% Estimation of the cumulant matrices.
%   ====================================
% if verbose, fprintf('jade -> Estimating cumulant matrices\n'); end

%% Reshaping of the data, hoping to speed up things a little bit...
X = X';

dimsymm 	= (m*(m+1))/2;	% Dim. of the space of real symm matrices
nbcm 		= dimsymm  ; 	% number of cumulant matrices
CM 		= zeros(m,m*nbcm);  % Storage for cumulant matrices
R 		= eye(m);  	%% 
Qij 		= zeros(m);	% Temp for a cum. matrix
Xim		= zeros(m,1);	% Temp
Xijm		= zeros(m,1);	% Temp
Uns		= ones(1,m);    % for convenience


%% I am using a symmetry trick to save storage.  I should write a short note one of these
%% days explaining what is going on here.
%%
Range     = 1:m ; % will index the columns of CM where to store the cumulant matrices.

for im = 1:m
  Xim = X(:,im) ;
  Xijm= Xim.*Xim ;
  %% Note to myself: the -R on next line can be removed: it does not affect
  %% the joint diagonalization criterion
  Qij           = ((Xijm(:,Uns).*X)' * X)/T - R - 2 * R(:,im)*R(:,im)' ;
  CM(:,Range)	= Qij ; 
  Range         = Range  + m ; 
  for jm = 1:im-1
    Xijm        = Xim.*X(:,jm) ;
    Qij         = sqrt(2) *(((Xijm(:,Uns).*X)' * X)/T - R(:,im)*R(:,jm)' - R(:,jm)*R(:,im)') ;
    CM(:,Range)	= Qij ;  
    Range       = Range  + m ;
  end ;
end;
%%%% Now we have nbcm = m(m+1)/2 cumulants matrices stored in a big m x m*nbcm array.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% The inefficient code below does the same as above: computing the big CM cumulant matrix.
%% It is commented out but you can check that it produces the same result.
%% This is supposed to help interested people understand the (rather obscure) code above.
%% See section 4.2 of the Neural Comp paper referenced below.  It can be found at
%% "http://www.tsi.enst.fr/~cardoso/Papers.PS/neuralcomp_2ppf.ps",
%%
%% 
%%  
%%  if 1,
%%  
%%    %% Step one: we compute the sample cumulants
%%    Matcum = zeros(m,m,m,m) ;
%%    for i1=1:m,
%%      for i2=1:m,
%%        for i3=1:m,
%%  	for i4=1:m,
%%  	  Matcum(i1,i2,i3,i4) = mean( X(:,i1) .* X(:,i2) .* X(:,i3) .* X(:,i4) ) ...
%%  	      - R(i1,i2)*R(i3,i4) ...
%%  	      - R(i1,i3)*R(i2,i4) ...
%%  	      - R(i1,i4)*R(i2,i3) ;
%%  	end
%%        end
%%      end
%%    end
%%    
%%    %% Step 2; We compute a basis of the space of symmetric m*m matrices
%%    CMM = zeros(m, m, nbcm) ;  %% Holds the basis.   
%%    icm = 0                 ;  %% index to the elements of the basis
%%    vi          = zeros(m,1);  %% the ith basis vetor of R^m
%%    vj          = zeros(m,1);  %% the jth basis vetor of R^m
%%    Id          = eye  (m)  ;  %%  convenience
%%    for im=1:m,
%%      vi             = Id(:,im) ;
%%      icm            = icm + 1 ;
%%      CMM(:, :, icm) = vi*vi' ;
%%      for jm=1:im-1,
%%        vj             = Id(:,jm) ;
%%        icm            = icm + 1 ;
%%        CMM(:, :, icm) = sqrt(0.5) * (vi*vj'+vj*vi') ;
%%      end
%%    end
%%    %% Now CMM(:,:,i) is the ith element of an orthonormal basis for_ the space of m*m symmetric matrices
%%    
%%    %% Step 3.  We compute the image of each basis element by the cumulant tensor and store it back into CMM.
%%    mat = zeros(m) ; %% tmp
%%    for icm=1:nbcm
%%      mat = squeeze(CMM(:,:,icm)) ;
%%      for i1=1:m
%%        for i2=1:m
%%  	CMM(i1, i2, icm) = sum(sum(squeeze(Matcum(i1,i2,:,:))  .* mat )) ;
%%        end
%%      end
%%    end;
%%    %% This is doing something like  \sum_kl [ Cum(xi,xj,xk,xl) * mat_kl ] 
%%    
%%    %% Step 4.  Now, we can check that CMM and CM are equivalent
%%    Range = 1:m ;
%%    for icm=1:nbcm,
%%      M1    = squeeze( CMM(:,:,icm)) ;
%%      M2    = CM(:,Range) ; 
%%      Range = Range  + m ; 
%%      norm (M1-M2, 'fro' ) , %% This should be a numerical zero.
%%    end;
%%  
%%  end;  %%  End of the demo code for the computation of cumulant matrices
%%  
%%  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%% Joint diagonalization of the cumulant matrices
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% Init
if 0, 	%% Init by diagonalizing a *single* cumulant matrix.  It seems to save
	%% some computation time `sometimes'.  Not clear if initialization is really worth
	%% it since Jacobi rotations are very efficient.  On the other hand, it does not
	%% cost much...

% 	if verbose, fprintf('jade -> Initialization of the diagonalization\n'); end
	[V,D]	= eig(CM(:,1:m)); % Selectng a particular cumulant matrix.
	for u=1:m:m*nbcm,         % Accordingly updating the cumulant set given the init
		CM(:,u:u+m-1) = CM(:,u:u+m-1)*V ; 
	end;
	CM	= V'*CM;

else,	%% The dont-try-to-be-smart init
	V	= eye(m) ; % la rotation initiale
end;

%% Computing the initial value of the contrast 
Diag    = zeros(m,1) ;
On      = 0 ;
Range   = 1:m ;
for im = 1:nbcm,
  Diag  = diag(CM(:,Range)) ;
  On    = On + sum(Diag.*Diag) ;
  Range = Range + m ;
end
Off = sum(sum(CM.*CM)) - On ;


seuil	= 1.0e-6 / sqrt(T) ; % A statistically scaled threshold on `small' angles
encore	= 1;
sweep	= 0; % sweep number
updates = 0; % Total number of rotations
upds    = 0; % Number of rotations in a given seep
g	= zeros(2,nbcm);
gg	= zeros(2,2);
G	= zeros(2,2);
c	= 0 ;
s 	= 0 ;
ton	= 0 ;
toff	= 0 ;
theta	= 0 ;
Gain    = 0 ;

%% Joint diagonalization proper
% if verbose, fprintf('jade -> Contrast optimization by joint diagonalization\n'); end

while encore, encore=0;   

%   if verbose, fprintf('jade -> Sweep #%3d',sweep); end
  sweep = sweep+1;
  upds  = 0 ; 
  Vkeep = V ;
  
  for p=1:m-1,
    for q=p+1:m,

      Ip = p:m:m*nbcm ;
      Iq = q:m:m*nbcm ;
      
      %%% computation of Givens angle
      g	    = [ CM(p,Ip)-CM(q,Iq) ; CM(p,Iq)+CM(q,Ip) ];
      gg    = g*g';
      ton   = gg(1,1)-gg(2,2); 
      toff  = gg(1,2)+gg(2,1);
      theta = 0.5*atan2( toff , ton+sqrt(ton*ton+toff*toff) );
      Gain  = (sqrt(ton*ton+toff*toff) - ton) / 4 ;
      
      %%% Givens update
      if abs(theta) > seuil,
%%      if Gain > 1.0e-3*On/m/m ,
	encore  = 1 ;
	upds    = upds    + 1;
	c	= cos(theta); 
	s	= sin(theta);
	G	= [ c -s ; s c ] ;
	
	pair 		= [p;q] ;
	V(:,pair) 	= V(:,pair)*G ;
	CM(pair,:)	= G' * CM(pair,:) ;
	CM(:,[Ip Iq]) 	= [ c*CM(:,Ip)+s*CM(:,Iq) -s*CM(:,Ip)+c*CM(:,Iq) ] ;
	

	On   = On  + Gain;
	Off  = Off - Gain;
	
	%% fprintf('jade -> %3d %3d %12.8f\n',p,q,Off/On);
      end%%of the if
    end%%of the loop on q
  end%%of the loop on p
%   if verbose, fprintf(' completed in %d rotations\n',upds); end
  updates = updates + upds ;
  
end%%of the while loop
% if verbose, fprintf('jade -> Total of %d Givens rotations\n',updates); end


%%% A separating matrix
%   ===================
B	= V'*B ;


%%% Permut the rows of the separating matrix B to get the most energetic components first.
%%% Here the **signals** are normalized to unit variance.  Therefore, the sort is
%%% according to the norm of the columns of A = pinv(B)

% if verbose, fprintf('jade -> Sorting the components\n',updates); end
A           = pinv(B) ;
[Ds,keys]   = sort(sum(A.*A)) ;
B           = B(keys,:)       ;
B           = B(m:-1:1,:)     ; % Is this smart ?


% Signs are fixed by forcing the first column of B to have non-negative entries.

% if verbose, fprintf('jade -> Fixing the signs\n',updates); end
b	= B(:,1) ;
signs	= sign(sign(b)+0.1) ; % just a trick to deal with sign=0
B	= diag(signs)*B ;



return ;


% To do.
%   - Implement a cheaper/simpler whitening (is it worth it?)
% 
% Revision history:
%
%- V1.9, August 2013
%  - Added BSD licence
%
%- V1.8, May 2005
%  - Added some commented code to explain the cumulant computation tricks.
%  - Added reference to the Neural Comp. paper.
%
%-  V1.7, Nov. 16, 2002
%   - Reverted the mean removal code to an earlier version (not using 
%     repmat) to keep the code octave-compatible.  Now less efficient,
%     but does not make any significant difference wrt the total 
%     computing cost.
%   - Remove some cruft (some debugging figures were created.  What 
%     was this stuff doing there???)
%
%
%-  V1.6, Feb. 24, 1997 
%   - Mean removal is better implemented.
%   - Transposing X before computing the cumulants: small speed-up
%   - Still more comments to emphasize the relationship to PCA
%
%-  V1.5, Dec. 24 1997 
%   - The sign of each row of B is determined by letting the first element be positive.
%
%-  V1.4, Dec. 23 1997 
%   - Minor clean up.
%   - Added a verbose switch
%   - Added the sorting of the rows of B in order to fix in some reasonable way the
%     permutation indetermination.  See note 2) below.
%
%-  V1.3, Nov.  2 1997 
%   - Some clean up.  Released in the public domain.
%
%-  V1.2, Oct.  5 1997 
%   - Changed random picking of the cumulant matrix used for initialization to a
%     deterministic choice.  This is not because of a better rationale but to make the
%     ouput (almost surely) deterministic.
%   - Rewrote the joint diag. to take more advantage of Matlab's tricks.
%   - Created more dummy variables to combat Matlab's loose memory management.
%
%-  V1.1, Oct. 29 1997.
%    Made the estimation of the cumulant matrices more regular. This also corrects a
%    buglet...
%
%-  V1.0, Sept. 9 1997. Created.
%
% Main references:
% @article{CS-iee-94,
%  title 	= "Blind beamforming for non {G}aussian signals",
%  author       = "Jean-Fran\c{c}ois Cardoso and Antoine Souloumiac",
%  HTML 	= "ftp://sig.enst.fr/pub/jfc/Papers/iee.ps.gz",
%  journal      = "IEE Proceedings-F",
%  month = dec, number = 6, pages = {362-370}, volume = 140, year = 1993}
%
%
%@article{JADE:NC,
%  author  = "Jean-Fran\c{c}ois Cardoso",
%  journal = "Neural Computation",
%  title   = "High-order contrasts for independent component analysis",
%  HTML    = "http://www.tsi.enst.fr/~cardoso/Papers.PS/neuralcomp_2ppf.ps",
%  year    = 1999, month =	jan,  volume =	 11,  number =	 1,  pages =	 "157-192"}
%
%
%
%
%  Notes:
%  ======
%
%  Note 1) The original Jade algorithm/code deals with complex signals in Gaussian noise
%  white and exploits an underlying assumption that the model of independent components
%  actually holds.  This is a reasonable assumption when dealing with some narrowband
%  signals.  In this context, one may i) seriously consider dealing precisely with the
%  noise in the whitening process and ii) expect to use the small number of significant
%  eigenmatrices to efficiently summarize all the 4th-order information.  All this is done
%  in the JADE algorithm.
%
%  In *this* implementation, we deal with real-valued signals and we do NOT expect the ICA
%  model to hold exactly.  Therefore, it is pointless to try to deal precisely with the
%  additive noise and it is very unlikely that the cumulant tensor can be accurately
%  summarized by its first n eigen-matrices.  Therefore, we consider the joint
%  diagonalization of the *whole* set of eigen-matrices.  However, in such a case, it is
%  not necessary to compute the eigenmatrices at all because one may equivalently use
%  `parallel slices' of the cumulant tensor.  This part (computing the eigen-matrices) of
%  the computation can be saved: it suffices to jointly diagonalize a set of cumulant
%  matrices.  Also, since we are dealing with reals signals, it becomes easier to exploit
%  the symmetries of the cumulants to further reduce the number of matrices to be
%  diagonalized.  These considerations, together with other cheap tricks lead to this
%  version of JADE which is optimized (again) to deal with real mixtures and to work
%  `outside the model'.  As the original JADE algorithm, it works by minimizing a `good
%  set' of cumulants.
%
%
%  Note 2) The rows of the separating matrix B are resorted in such a way that the columns
%  of the corresponding mixing matrix A=pinv(B) are in decreasing order of (Euclidian)
%  norm.  This is a simple, `almost canonical' way of fixing the indetermination of
%  permutation.  It has the effect that the first rows of the recovered signals (ie the
%  first rows of B*X) correspond to the most energetic *components*.  Recall however that
%  the source signals in S=B*X have unit variance.  Therefore, when we say that the
%  observations are unmixed in order of decreasing energy, this energetic signature is to
%  be found as the norm of the columns of A=pinv(B) and not as the variances of the
%  separated source signals.
%
%
%  Note 3) In experiments where JADE is run as B=jadeR(X,m) with m varying in range of
%  values, it is nice to be able to test the stability of the decomposition.  In order to
%  help in such a test, the rows of B can be sorted as described above. We have also
%  decided to fix the sign of each row in some arbitrary but fixed way.  The convention is
%  that the first element of each row of B is positive.
%
%
%  Note 4) Contrary to many other ICA algorithms, JADE (or least this version) does not
%  operate on the data themselves but on a statistic (the full set of 4th order cumulant).
%  This is represented by the matrix CM below, whose size grows as m^2 x m^2 where m is
%  the number of sources to be extracted (m could be much smaller than n).  As a
%  consequence, (this version of) JADE will probably choke on a `large' number of sources.
%  Here `large' depends mainly on the available memory and could be something like 40 or
%  so.  One of these days, I will prepare a version of JADE taking the `data' option
%  rather than the `statistic' option.


% JadeR.m ends here.
end


function Hd = filtro_fir_2_6_250b
%FILTRO_FIR_2_6_250B Returns a discrete-time filter object.

%
% MATLAB Code
% Generated by MATLAB(R) 7.11 and the Signal Processing Toolbox 6.14.
%
% Generated on: 22-Feb-2014 15:45:45
%

% FIR Window Highpass filter designed using the FIR1 function.

% All frequency values are in Hz.
Fs = 250;  % Sampling Frequency

Fstop = 2;               % Stopband Frequency
Fpass = 6;               % Passband Frequency
Dstop = 0.01;            % Stopband Attenuation
Dpass = 0.057501127785;  % Passband Ripple
flag  = 'scale';         % Sampling Flag

% Calculate the order from the parameters using KAISERORD.
[N,Wn,BETA,TYPE] = kaiserord([Fstop Fpass]/(Fs/2), [0 1], [Dpass Dstop]);

% Calculate the coefficients using the FIR1 function.
b  = fir1(N, Wn, TYPE, kaiser(N+1, BETA), flag);
Hd = dfilt.dffir(b);

% [EOF]
end

function Hd = filtro_fir_45_50_250
%FILTRO_FIR_45_50_250 Returns a discrete-time filter object.

%
% MATLAB Code
% Generated by MATLAB(R) 7.11 and the Signal Processing Toolbox 6.14.
%
% Generated on: 22-Feb-2014 15:45:11
%

% FIR Window Lowpass filter designed using the FIR1 function.

% All frequency values are in Hz.
Fs = 250;  % Sampling Frequency

Fpass = 45;              % Passband Frequency
Fstop = 50;              % Stopband Frequency
Dpass = 0.057501127785;  % Passband Ripple
Dstop = 0.01;            % Stopband Attenuation
flag  = 'scale';         % Sampling Flag

% Calculate the order from the parameters using KAISERORD.
[N,Wn,BETA,TYPE] = kaiserord([Fpass Fstop]/(Fs/2), [1 0], [Dstop Dpass]);

% Calculate the coefficients using the FIR1 function.
b  = fir1(N, Wn, TYPE, kaiser(N+1, BETA), flag);
Hd = dfilt.dffir(b);

% [EOF]
end


function Hd = filtro_fir_1_2_1000
%FILTRO_FIR_1_2_1000 Returns a discrete-time filter object.

%
% MATLAB Code
% Generated by MATLAB(R) 7.11 and the Signal Processing Toolbox 6.14.
%
% Generated on: 22-Feb-2014 13:58:10
%

% FIR Window Highpass filter designed using the FIR1 function.

% All frequency values are in Hz.
Fs = 1000;  % Sampling Frequency

Fstop = 1;               % Stopband Frequency
Fpass = 2;               % Passband Frequency
Dstop = 0.01;            % Stopband Attenuation
Dpass = 0.057501127785;  % Passband Ripple
flag  = 'scale';         % Sampling Flag

% Calculate the order from the parameters using KAISERORD.
[N,Wn,BETA,TYPE] = kaiserord([Fstop Fpass]/(Fs/2), [0 1], [Dpass Dstop]);

% Calculate the coefficients using the FIR1 function.
b  = fir1(N, Wn, TYPE, kaiser(N+1, BETA), flag);
Hd = dfilt.dffir(b);

% [EOF]
end


function Hd = filtro_fir_46_50_1000
%FILTRO_FIR_46_50_1000 Returns a discrete-time filter object.

%
% MATLAB Code
% Generated by MATLAB(R) 7.11 and the Signal Processing Toolbox 6.14.
%
% Generated on: 22-Feb-2014 13:59:18
%

% FIR Window Lowpass filter designed using the FIR1 function.

% All frequency values are in Hz.
Fs = 1000;  % Sampling Frequency

Fpass = 46;              % Passband Frequency
Fstop = 50;              % Stopband Frequency
Dpass = 0.057501127785;  % Passband Ripple
Dstop = 0.01;            % Stopband Attenuation
flag  = 'scale';         % Sampling Flag

% Calculate the order from the parameters using KAISERORD.
[N,Wn,BETA,TYPE] = kaiserord([Fpass Fstop]/(Fs/2), [1 0], [Dstop Dpass]);

% Calculate the coefficients using the FIR1 function.
b  = fir1(N, Wn, TYPE, kaiser(N+1, BETA), flag);
Hd = dfilt.dffir(b);

% [EOF]
end
