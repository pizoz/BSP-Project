function fqrs=choosechannelmix2(FQRS,Ltime,fs)

  %%FQRS is cell array containing the annotattions for each channel
  %%Ltime is ecg length in time
  %%fs is the sampling frequency

  %%in this version (mix2)
  %%instead of 'choosegmentchannel' its used 'choosegmentfinalchannel'


  N=size(FQRS,1);

  ltsegment1=3;
  fqrs1=choosechannelbysegment(FQRS,Ltime,fs,ltsegment1);

  ltsegment2=10;
  fqrs2=choosechannelbysegment(FQRS,Ltime,fs,ltsegment2);

  ltsegment3=20;
  fqrs3=choosechannelbysegment(FQRS,Ltime,fs,ltsegment3);

  FQRS{N+1,1}=fqrs1;
  FQRS{N+2,1}=fqrs2;
  FQRS{N+3,1}=fqrs3;

  channel=choosegmentfinalchannel(FQRS,N+3,fs);
  %printf('channel %d\n',channel);
  fqrs=FQRS{channel};

end



function fqrs=choosechannelbysegment(FQRS,Ltime,fs,ltsegment)
  
  %%FQRS are the fqrs annotations for the available channels
  %%Ltime is ECG time length, secs  
  %%fs is the sampling frequency
  %%ltsegment is the time length, secs, of segments in which the ecg will be
  %%divided: for each segment it will be chosen one channel


  %%minimum distance between two fqrs
  minlap=floor(320*fs/1000);%320
  %% should be the same as
  %% minimumfqrsinterval in 'detectfqrssupressnew'

  lsamples=Ltime*fs; %numsamples ecg
  N=length(FQRS);   % number of channels
  assert(N==4);

  %%samples
  lsegment=ltsegment*fs;

  fqrs=[];

  segments=[];%%segments last sample
  lastend=lsegment;
  while(lastend<=lsamples)
    segments=[segments,lastend];
    lastend=lastend+lsegment;
  end
  segments(end)=lsamples;

  %%debug
  %printf('length(segments) is %d\n',length(segments));fflush(stdout);

  %stats=zeros(N,2);

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%initial segment (longuer than the other)
  %%%%%%%%%%%%%%%
  
  finish=segments(1);
  
  for i=1:N
    aux=FQRS{i};
    data{i}=aux(aux<=segments(1));
  end
  channel=choosegmentfinalchannel(data,N,fs);

  F=FQRS{channel};
  if(length(F)>0)
    fqrs=F(F<=finish);
  end

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %% all the other channels but the last

  if(length(segments)>1)

    ordsegment=2;

    while(ordsegment<length(segments))

      start=segments(ordsegment-1); 
      finish=segments(ordsegment);  
   
      for i=1:N
	data{i}=FQRS{i}(FQRS{i}<=segments(ordsegment));
	data{i}=data{i}(data{i}>=start);
      end

      
      if(length(fqrs)>0)
	  for i=1:N	    
	    if(length(data{i})>0)
	      if(abs(fqrs(end)-data{i}(1))<minlap)
		data{i}=data{i}(2:end);
	      end
	    end
	  end

	for i=1:N
	  auxdata{i}=[fqrs(end),data{i}];
	end      
      else
	for i=1:N
	  auxdata{i}=data{i};
	end
      end  
     

      channel=choosegmentfinalchannel(auxdata,N,fs);

      F=FQRS{channel};
    
      F=F(F<=finish);
      F=F(F>segments(ordsegment-1));
  

      if(length(F)>0)
	if(length(fqrs)>0)
	  if(abs(fqrs(end)-F(1))<minlap)
	    F=F(2:end);
	  end
	end    
	fqrs=[fqrs,F];
      end  
      ordsegment=ordsegment+1;

      %%prinf('ordsegment=%d\n',ordsegment);fflush(stdout);

    end

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %%  last segment

   start=segments(ordsegment-1);  %used to compute median
   finish=lsamples;   %used to select detections

   for i=1:N
     data{i}=FQRS{i}(FQRS{i}>start);
   end

   if(length(fqrs)>0)
     for i=1:N
       if(length(data{i})>0)
	 if(abs(fqrs(end)-data{i}(1))<minlap)
	   data{i}=data{i}(2:end);
	 end
       end     
     end
     

     for i=1:N
       auxdata{i}=[fqrs(end),data{i}];
      end  
    else
      auxdata{i}=data{i};
   end  

   channel=choosegmentfinalchannel(data,N,fs);
   
   
   F=FQRS{channel};
   F=F(F>segments(ordsegment-1));

   if(length(fqrs)>1)
     if(abs(fqrs(end)-F(1))<minlap)
       F=F(2:end);
     end
   end
   fqrs=[fqrs,F];
   
end

end


% function channel=choosegmentchannel(datas,N)

%   w=zeros(1,2);
%   w(1)=-1;%num fqrs is the most importante factor
%   w(2)=0.5;%low deviation is the other factor 

%   %%begin,finish->not in use but an option

%   stats=zeros(N,2);

%   for i=1:N

%     data=diff(datas{i});
%     stats(i,1)=length(data);
%     if(length(data)>2)
%       m=median(data);
%       %%data=data(data<=finish);
%       %%data=data(data>=begin);
%       data=data-m;
%       stats(i,2)=sqrt(mean(data.^2));%mean(abs(data.^3));
%     end
%   end

%   if(any(stats))
%     aux=zeros(1,N);
%     for i=1:N
%       aux(i)=stats(i,:)*w';% this is the had hoc score for channel i
%     end

%     [a channel]=min(aux(:));
%     %%if the stats for these channel are all zero replace it
%     if(~any(stats(channel,:)))
%       b=max(aux(:));
%       aux(channel)=b;

%       [a channel]=min(aux(:));
%     end
%   else   %no detections in any channel
%     channel=0;
%   end

%   assert(channel<=N);

% end


%%inspired by Behar&Clifford
%
function channel=choosegmentfinalchannel(datas,N,fs)

  %% num HR variation > 30  is the most importante factor

  threshold=30;%penalize if 

  for i=1:N

    stats(i,1)=10000;

    numsampminute=60*fs;

    if(length(datas{i})>2)

      data=diff(datas{i});
      datasaux=data(1:end-1);
      stats(i,1)=-length(data)+std(data);
%+0.25*sum(abs(diff(data))>threshold*datasaux.^2/numsampminute)

    end
  end

  
  [a channel]=min(stats(:));

end