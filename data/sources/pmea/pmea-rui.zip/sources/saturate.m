function data=saturate(data)
%Copyright (C) 2013 Rui Rodrigues <rapr@fct.unl.pt>
%This software is released under the terms of the GNU General Public License (http://www.gnu.org/copyleft/gpl.html)
  numchannels=size(data,1);

  maximums=max(abs(data'));

  factor=1.2;

  limit=factor*median(maximums);

  data(data>limit)=limit;

  data(data<-limit)=-limit;

end
