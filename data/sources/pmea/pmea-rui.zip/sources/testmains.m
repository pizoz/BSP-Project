function [a b]=testmains(ecg,Fs)

  L=length(ecg);
  T = 1/Fs;
  t = (0:L-1)*T;  

  NFFT = 2^nextpow2(L);
  Y = fft(ecg,NFFT)/L;

  center50=ceil(32769/(500/50));
  delta50=center50-3:center50+3;
  power50Hz=sum((abs(Y(delta50).^2)));

  center60=ceil(32769/(500/60));
  delta60=center60-3:center60+3;
  power60Hz=sum((abs(Y(delta60).^2)));

  a=power50Hz;
  b=power60Hz;

