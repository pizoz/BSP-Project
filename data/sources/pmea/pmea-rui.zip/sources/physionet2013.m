function [fetal_QRSAnn_est,QT_Interval] = physionet2013(tm,ECG)
% Template algorithm for Physionet/CinC competition 2013. This function can
% be used for events 1 and 2. Participants are free to modify any
% components of the code. However the function prototype must stay the
% same:
%
% [fetal_QRSAnn_est,QT_Interval] = physionet2013(tm,ECG) where the inputs and outputs are specified
% below.
%
% inputs:
%   ECG: 4x60000 (4 channels and 1min of signal at 1000Hz) matrix of
%   abdominal ECG channels.
%   tm : Nx1 vector of time in milliseconds -> not used
% output:
%   fetal_QRSAnn_est: FQRS markers in milliseconds. Each marker indicates the position of one
%   of the FQRS detected by the algorithm.
%Copyright (C) 2013 Rui Rodrigues <rapr@fct.unl.pt>
%This software is released under the terms of the GNU General Public License (http://www.gnu.org/copyleft/gpl.html)


  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %% you can use the global or the time adaptive versions
  %%
  %% global version: (you need to  uncomment some lines and comment others)
  %%
  %% supressFECG(i,:) =  supressmqrsuseall(..)
  %%
  %% use 'choosechannelnew2(stats)' and the instructions necessary to
  %% produce stats
  %%
  %%
  %% time adaptive version : (use the file as it is now)
  %%
  %% supressFECG(i,:) =  supressmqrsuseall_adaptive (..)
  %%
  %% fetal_QRSAnn_est = choosechannelmix2(..)




  %%replace nans
  ECG(find(isnan(ECG)))=0;

  %% ---- check size of ECG ----
  if size(ECG,1)>size(ECG,2)
    ECG = ECG';
  end

  fs      = 1000;             % sampling frequency
  N       = size(ECG,1);      % number of abdominal channels

  %% ---- preprocessing ----
  [FilteredECG] = preprocessing_v2(ECG,fs);

  %% maternal QRS detection
  mqrs=detectqrsmultichannel2(FilteredECG,fs);


  %% ---- MECG cancellation ----

  if(length(mqrs)>0)

    samplingrate=fs;

    qrsL=floor(130*samplingrate/1000); %130ms 
    modelorder=91; % it is adapted for 1000 Hz fs: must be changed when fs
		 % changes-> to be done
    olsdata=preparedata2supressmqrs(FilteredECG, mqrs, qrsL, modelorder, fs);

    %%%%%%%%%%%%%%%%%%%%%
    %% use 'supressmqrsuseall' for the global version
    %%
    %% use 'supressmqrsuseall_adaptive' for the time adaptive version
    %%
    for i=1:N               % run algorithm for each channel
      supressFECG(i,:) =  supressmqrsuseall_adaptive(FilteredECG,i,mqrs,olsdata,modelorder);
    % supressFECG(i,:) =  supressmqrsuseall(FilteredECG,i,mqrs,olsdata,modelorder);
  end


  %% ---- FQRS detection ----

  FQRS = cell(N,1);

  for i=1:N
    FQRS{i,1}=detectfqrsupressnew(supressFECG(i,:),fs);
  end





  %% ---- channel selection based on statistics obtained on the fqrs and
  %% mqrs detected
  %%
  %%  uncomment the following lines for GLOBAL VERSION
  % numstats=2;
  % stats=zeros(N,numstats);
  % for i=1:N
  %   if(length(FQRS{i,1})>2 &&  length(mqrs>2))
  %     aux=[length(FQRS{i,1}),std(diff(FQRS{i,1}))];
  %     stats(i,:)=aux;
  %   end
  % end

  % channel=choosechannelnew2(stats);
  % printf('                        chosen channel is %d\r',channel);fflush(stdout);
  % fetal_QRSAnn_est    = round(1000*FQRS{channel,1}'/fs);


  %% Comment the following lines for GLOBAL VERSION 
  Ltime=60;
  fetal_QRSAnn_est = choosechannelmix2(FQRS,Ltime,fs)';
  QT_Interval         = 0;


end





