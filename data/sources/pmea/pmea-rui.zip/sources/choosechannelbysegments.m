function fqrs=choosechannelbysegments(FQRS,Ltime,fs)
  
  %%FQRS are the fqrs annotations for the available channels
  %%Ltime is ECG time length  
  %%fs is the sampling frequency

  %%minimum distance between two fqrs
  minlap=floor(320*fs/1000);  % should be the same as
				% minimumfqrsinterval in 'detectfqrssupressnew'

  lsamples=Ltime*fs; %numsamples ecg
  N=length(FQRS);   % number of channels
  assert(N==4);

  %%samples
  lsegment=3*fs;
  lsides=0*fs;

  fqrs=[];

  segments=[];%%segments last sample
  lastend=lsides+lsegment+lsides;
  while(lastend<=lsamples)
    segments=[segments,lastend];
    lastend=lastend+lsegment;
  end
  segments(end)=lsamples;

  %%debug
  %printf('length(segments) is %d\n',length(segments));fflush(stdout);

  %stats=zeros(N,2);

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%initial segment (longuer than the other)
  %%%%%%%%%%%%%%%
  
  if(length(segments)>1)  %last portion is used only to compute median
    finish=segments(1)-lsides;
  else
    finish=segments(1);
  end

  for i=1:N
    aux=FQRS{i};
    data{i}=aux(aux<=segments(1));
  end
  channel=choosegmentchannel(data,N);

  if(channel)
    F=FQRS{channel};
    fqrs=F(F<=finish);
  end

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %% all the other channels but the last

  if(length(segments)>1)

    ordsegment=2;

    while(ordsegment<length(segments))

      start=segments(ordsegment-1)-lsides;  %used to compute median
      finish=segments(ordsegment)-lsides;   %used to select detections
   
      for i=1:N
	data{i}=FQRS{i}(FQRS{i}<=segments(ordsegment));
	data{i}=data{i}(data{i}>=start);
      end
      channel=choosegmentchannel(data,N);
      
      if(channel)
	F=FQRS{channel};
	F=F(F<=finish);
	F=F(F>segments(ordsegment-1));
  
	if(length(fqrs)>0)
	  if(abs(fqrs(end)-F(1))<minlap)
	    F=F(2:end);
	  end
	end    
	fqrs=[fqrs,F];
      end  
      ordsegment=ordsegment+1;

      %%prinf('ordsegment=%d\n',ordsegment);fflush(stdout);

    end

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %%  last segment

   start=segments(ordsegment-1)-lsides;  %used to compute median
   finish=lsamples;   %used to select detections

   for i=1:N
     data{i}=FQRS{i}(FQRS{i}>start);
   end
   channel=choosegmentchannel(data,N);
   
   if(channel)
     F=FQRS{channel};
     F=F(F>segments(ordsegment-1));

     if(length(fqrs)>1)
       if(abs(fqrs(end)-F(1))<minlap)
	 F=F(2:end);
       end
     end
   fqrs=[fqrs,F];
   end


end

end


function channel=choosegmentchannel(datas,N)

  w=zeros(1,2);
  w(1)=-1;%num fqrs is the most importante factor
  w(2)=0.5;%low deviation is the other factor 

  %%begin,finish->not in use but an option

  stats=zeros(N,2);

  for i=1:N

    data=diff(datas{i});
    stats(i,1)=length(data);
    if(length(data)>2)
      m=median(data);
      %%data=data(data<=finish);
      %%data=data(data>=begin);
      data=data-m;
      stats(i,2)=sqrt(mean(data.^2));%mean(abs(data.^3));
    end
  end

  if(any(stats))
    aux=zeros(1,N);
    for i=1:N
      aux(i)=stats(i,:)*w';% this is the had hoc score for channel i
    end

    [a channel]=min(aux(:));
    %%if the stats for these channel are all zero replace it
    if(~any(stats(channel,:)))
      b=max(aux(:));
      aux(channel)=b;

      [a channel]=min(aux(:));
    end
  else   %no detections in any channel
    channel=0;
  end

  assert(channel<5);

end