function ...
      newecgchannel=supressmqrsuseall_adaptive(allchannelsecg,thischannel,mqrs, ...
					       olsdata,modelorder)
%ordermodel must be an odd integer
% olsdata is created by function 'preparedata2supressmqrs'
%use all the other channels to reconstruct this channel mqrs
%Copyright (C) 2013 Rui Rodrigues <rapr@fct.unl.pt>
%This software is released under the terms of the GNU General Public License (http://www.gnu.org/copyleft/gpl.html)

  % Change if you use a diffrent sampling rate
  samplingrate=1000;


  qrsL=floor(130*samplingrate/1000);%130ms used in 'set2zeromqrs'

  numqrs=length(mqrs);

  %%%%%% parameters for the adptive version%%%%%%%%%%%%%%%
  %%
  %% number of initial mqrs used to create filter before 
  %% adaptive procedure starts
  numinitialmqrs=25;
  %%
  %%nummqrs used to create un update (call to ols)
  num2update=10;%best 10;
  %%
  %%number of filter updates
  numupdates=floor((numqrs-numinitialmqrs)/num2update);
  %% scaling factor (small) used to update filter after eacg mqrs
  epsilon=0.3;
  %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  %%verify olsdata is correct ----------------------------
  numchannels=size(allchannelsecg,1);
  L=length(allchannelsecg);
  halfqrsL=floor(qrsL/2);
  halfmodelorder=(modelorder-1)/2;
  numsamplesperqrs=2*halfqrsL+1;

  
  if(mqrs(1)<=halfqrsL+halfmodelorder)
    mqrs=mqrs(1,2:end);
    numqrs=numqrs-1;
  end
  if(mqrs(end)>L-halfqrsL-halfmodelorder)
    mqrs=mqrs(1,1:end-1);
    numqrs=numqrs-1;
  end

  [a b c]=size(olsdata);

  assert(a==numqrs*(2*halfqrsL+1));
  assert(b==modelorder);
  assert(c==numchannels);

  %%end verify ols data---------------------------------------


  %% build arx model --------------------------------

  otherchannels=[];
  for i=1:numchannels
    if(i~=thischannel)
      otherchannels=[otherchannels,i];
    end
  end


  %%arx model generates middle point from  'order size' segment of all other
  %% channels

  middlepoint=(modelorder-1)/2+1;

  input=[];

  for i=otherchannels %use i channel to generate the 'otherchannels' in
		      %the neighbourood of mqrs
    input=[input,olsdata(:,:,i)];
  end

  output=olsdata(:,middlepoint,thischannel);

  newecgchannel=allchannelsecg(thischannel,:);

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %% initial filter(arx model) and supression of mqrs %%%%%%%%%%%%

  thisoutput=output(1:numinitialmqrs*(2*halfqrsL+1),1,1);
  thisinput=input(1:numinitialmqrs*(2*halfqrsL+1),:,:);

  [beta, sigma, r] = ols (thisoutput,thisinput); %beta is the filter
  recqrsthischannel=thisoutput-r;
 


  %%use  allecgsegmentsthischannel to replace mqrs segments in this channel ecg 

  for i=1:numinitialmqrs
    for j=-halfqrsL:halfqrsL

      newecgchannel(mqrs(i)+j)=allchannelsecg(thischannel,mqrs(i)+j)- ...
	  recqrsthischannel((i-1)*(2*halfqrsL+1)+j+1+halfqrsL);
    end
  end

  %%%%%%  end initial filter    %%%%%%%%%%%%%%%%%%%%%


 %%sequencial filter updates and mqrs supression

  start=numinitialmqrs*(2*halfqrsL+1);

  for update=1:numupdates

    if(update<numupdates)
      numusedmqrs=num2update;
    else
      numusedmqrs=numqrs-(numinitialmqrs+(update-1)*num2update);%last
				%mqrs complexes
    end

  
    thisoutput=output(start+1:start+numusedmqrs*(2*halfqrsL+1),1,1);
    thisinput=input(start+1:start+numusedmqrs*(2*halfqrsL+1),:,:);

    [newbeta, sigma, r] = ols (thisoutput,thisinput);

    %%deltabeta=newbeta-beta;

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%update filter %%%%%%%%%%%%%%%%%%
    beta=(1-epsilon)*beta+epsilon*newbeta;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


    recqrsthischannel=thisinput*beta;
 
    %%use  allecgsegmentsthischannel to replace mqrs segments in this
    %%channel ecg 
    begin=numinitialmqrs+(update-1)*num2update;
    for i=begin+1:begin+numusedmqrs
      for j=-halfqrsL:halfqrsL

	newecgchannel(mqrs(i)+j)=allchannelsecg(thischannel,mqrs(i)+j)- ...
	    recqrsthischannel((i-begin-1)*(2*halfqrsL+1)+j+1+halfqrsL);
      end
    end

    start=start+num2update*(2*halfqrsL+1);
    
  end

end