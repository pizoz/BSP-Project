Rui Rodrigues

Departamento de Matematica da
Faculdade de Ciencias e Tecnologia da 
Universidade Nova de Lisboa

2829-516 Caparica
Portugal

rapr@fct.unl.pt
