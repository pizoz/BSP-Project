function newecgchannel=supressmqrsuseall(allchannelsecg,thischannel,mqrs,...
					 olsdata,modelorder)
%ordermodel must be an odd integer
% olsdata is created by function 'preparedata2supressmqrs'
%use all the other channels to reconstruct this channel mqrs
%Copyright (C) 2013 Rui Rodrigues <rapr@fct.unl.pt>
%This software is released under the terms of the GNU General Public License (http://www.gnu.org/copyleft/gpl.html)

  %------------------------------------------------------------
  %%% Change sampling rate if you use a different one
  samplingrate=1000;

  qrsL=floor(130*samplingrate/1000);%130ms used in 'set2zeromqrs'

  %%verify olsdata is correct ----------------------------
  numchannels=size(allchannelsecg,1);
  L=length(allchannelsecg);
  halfqrsL=floor(qrsL/2);
  halfmodelorder=(modelorder-1)/2;
  numsamplesperqrs=2*halfqrsL+1;

  numqrs=length(mqrs);
  if(mqrs(1)<=halfqrsL+halfmodelorder)
    mqrs=mqrs(1,2:end);
    numqrs=numqrs-1;
  endif
  if(mqrs(end)>L-halfqrsL-halfmodelorder)
    mqrs=mqrs(1,1:end-1);
    numqrs=numqrs-1;
  endif

  [a b c]=size(olsdata);

  assert(a==numqrs*(2*halfqrsL+1));
  assert(b==modelorder);
  assert(c==numchannels);

  %%end verify -----------------------------------------


  % build arx model --------------------------------

  otherchannels=[];
  for i=1:numchannels
    if(i!=thischannel)
      otherchannels=[otherchannels,i];
    end
  end


  %% arx model generates middle point from  'order size' segment of another
  %% particular channel

  middlepoint=(modelorder-1)/2+1;

  input=[];

  for i=otherchannels %use i channel to generate the other channels in
		      %the neighbourood of mqrs


    input=[input,olsdata(:,:,i)];

  end

  output=olsdata(:,middlepoint,thischannel);

  [beta, sigma, r] = ols (output, input);
  recqrsthischannel=output-r;

 

  newecgchannel=allchannelsecg(thischannel,:);

  %%use  allecgsegmentsthischannel to replace mqrs segments in this channel ecg 

  for i=1:numqrs
    for j=-halfqrsL:halfqrsL

      newecgchannel(mqrs(i)+j)=allchannelsecg(thischannel,mqrs(i)+j)-\
	  recqrsthischannel((i-1)*(2*halfqrsL+1)+j+1+halfqrsL);
    end
  end

%printf("reconstruction channel is %d\n",best);


