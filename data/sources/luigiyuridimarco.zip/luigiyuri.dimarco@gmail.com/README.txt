Participant:

Luigi Yuri Di Marco
INSIGNEO Institute for In Silico Medicine
University of Sheffield, Sheffield, UK

mail: luigiyuri.dimarco@gmail.com

--------------------------------------
OPEN SOURCE

Main m-file:
       > physionet2013.m
            
Uses:
       > Signal Processing Toolbox
       > Statistics Toolbox
       > m-modules: 
                   BuildChain.m 
                   FindEMG.m 
                   MyAlignQRS.m
                   MyBeatDect.m
                   MyBuildSeq.m
                   MyFBeatDect.m 
                   MyRRTemplate.m
                         
   