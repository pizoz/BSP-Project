Alessia Dess�, Danilo Pani, Luigi Raffo
alessia.dessi@diee.unica.it
Department of Electrical and Electronic Engineering, University of Cagliari (Italy)
Events 1 and 2
