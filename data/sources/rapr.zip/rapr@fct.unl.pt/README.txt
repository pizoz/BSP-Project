Rui Rodrigues
Mathematics Department, Faculdade de Ciencias e Tecnologia da Universidade Nova de Lisboa

Departamento de Matematica
Faculdade de Ciências e Tecnologia da UNL
2829-516 Caparica
Portugal
